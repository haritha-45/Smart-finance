#include "Totp.h"
#include "Hmac.h"
#include "Base32.h"
#include <ctime>
#include <random>
#include <sstream>
#include <iomanip>
#include <cmath>

namespace sf {

Totp::Totp(int stepSeconds, int digits) : stepSeconds_(stepSeconds), digits_(digits) {}

std::string Totp::generate(const std::string& base32Secret, int64_t unixTime) const {
    if (unixTime < 0) {
        unixTime = static_cast<int64_t>(std::time(nullptr));
    }
    uint64_t counter = static_cast<uint64_t>(unixTime) / static_cast<uint64_t>(stepSeconds_);

    // Counter is encoded as an 8-byte big-endian value (RFC 4226 Section 5.2).
    std::vector<uint8_t> counterBytes(8);
    for (int i = 7; i >= 0; --i) {
        counterBytes[i] = static_cast<uint8_t>(counter & 0xFF);
        counter >>= 8;
    }

    std::vector<uint8_t> key = Base32::decode(base32Secret);
    std::vector<uint8_t> hash = Hmac::sha1(key, counterBytes);

    // Dynamic truncation (RFC 4226 Section 5.3).
    int offset = hash[hash.size() - 1] & 0x0F;
    uint32_t binCode = (static_cast<uint32_t>(hash[offset] & 0x7F) << 24) |
                        (static_cast<uint32_t>(hash[offset + 1] & 0xFF) << 16) |
                        (static_cast<uint32_t>(hash[offset + 2] & 0xFF) << 8) |
                        (static_cast<uint32_t>(hash[offset + 3] & 0xFF));

    uint32_t mod = static_cast<uint32_t>(std::pow(10, digits_));
    uint32_t otp = binCode % mod;

    std::ostringstream oss;
    oss << std::setw(digits_) << std::setfill('0') << otp;
    return oss.str();
}

bool Totp::verify(const std::string& base32Secret, const std::string& code, int window) const {
    if (code.empty()) return false;
    int64_t now = static_cast<int64_t>(std::time(nullptr));
    for (int i = -window; i <= window; ++i) {
        int64_t candidateTime = now + static_cast<int64_t>(i) * stepSeconds_;
        if (candidateTime < 0) continue;
        if (generate(base32Secret, candidateTime) == code) {
            return true;
        }
    }
    return false;
}

std::string Totp::generateSecret(size_t byteLength) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dist(0, 255);

    std::vector<uint8_t> raw(byteLength);
    for (auto& b : raw) b = static_cast<uint8_t>(dist(gen));
    return Base32::encode(raw);
}

std::string Totp::urlEncode(const std::string& value) {
    std::ostringstream oss;
    for (char c : value) {
        if (std::isalnum(static_cast<unsigned char>(c)) || c == '-' || c == '_' || c == '.' || c == '~') {
            oss << c;
        } else {
            oss << '%' << std::hex << std::uppercase << std::setw(2) << std::setfill('0')
                << static_cast<int>(static_cast<unsigned char>(c)) << std::nouppercase << std::dec;
        }
    }
    return oss.str();
}

std::string Totp::provisioningUri(const std::string& base32Secret, const std::string& accountName,
                                    const std::string& issuer) {
    std::ostringstream oss;
    oss << "otpauth://totp/" << urlEncode(issuer) << ":" << urlEncode(accountName)
        << "?secret=" << base32Secret
        << "&issuer=" << urlEncode(issuer)
        << "&algorithm=SHA1&digits=6&period=30";
    return oss.str();
}

} // namespace sf
