#include "Base32.h"
#include <algorithm>
#include <cctype>

namespace sf {

namespace {
    const std::string ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

    int8_t charValue(char c) {
        c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
        auto pos = ALPHABET.find(c);
        return pos == std::string::npos ? -1 : static_cast<int8_t>(pos);
    }
}

std::string Base32::encode(const std::vector<uint8_t>& data) {
    std::string result;
    int buffer = 0;
    int bitsLeft = 0;

    for (uint8_t byte : data) {
        buffer = (buffer << 8) | byte;
        bitsLeft += 8;
        while (bitsLeft >= 5) {
            int index = (buffer >> (bitsLeft - 5)) & 0x1F;
            result += ALPHABET[index];
            bitsLeft -= 5;
        }
    }
    if (bitsLeft > 0) {
        int index = (buffer << (5 - bitsLeft)) & 0x1F;
        result += ALPHABET[index];
    }
    // Pad to a multiple of 8 characters, per RFC 4648.
    while (result.size() % 8 != 0) {
        result += '=';
    }
    return result;
}

std::vector<uint8_t> Base32::decode(const std::string& base32Text) {
    std::vector<uint8_t> result;
    int buffer = 0;
    int bitsLeft = 0;

    for (char c : base32Text) {
        if (c == '=' || c == ' ' || c == '-') continue;
        int8_t val = charValue(c);
        if (val < 0) continue; // skip invalid characters defensively
        buffer = (buffer << 5) | val;
        bitsLeft += 5;
        if (bitsLeft >= 8) {
            result.push_back(static_cast<uint8_t>((buffer >> (bitsLeft - 8)) & 0xFF));
            bitsLeft -= 8;
        }
    }
    return result;
}

} // namespace sf
