#include "AuthService.h"
#include "Totp.h"
#include "PasswordHasher.h"
#include "Logger.h"
#include <iostream>
#include <limits>
#include <algorithm>
#include <cctype>

#if defined(_WIN32)
    #include <conio.h>
#else
    #include <termios.h>
    #include <unistd.h>
#endif

namespace sf {

namespace {
    constexpr int MAX_OTP_ATTEMPTS = 3;
}

std::string AuthService::promptLine(const std::string& prompt) {
    std::cout << prompt;
    std::string line;
    std::getline(std::cin, line);
    return line;
}

std::string AuthService::promptPasswordMasked(const std::string& prompt) {
    std::cout << prompt;
    std::string password;

#if defined(_WIN32)
    char ch;
    while ((ch = static_cast<char>(_getch())) != '\r' && ch != '\n') {
        if (ch == '\b') { // backspace
            if (!password.empty()) {
                password.pop_back();
                std::cout << "\b \b";
            }
        } else {
            password += ch;
            std::cout << '*';
        }
    }
    std::cout << std::endl;
#else
    termios oldSettings{};
    termios newSettings{};
    bool ttyAvailable = (tcgetattr(STDIN_FILENO, &oldSettings) == 0);
    if (ttyAvailable) {
        newSettings = oldSettings;
        newSettings.c_lflag &= ~static_cast<tcflag_t>(ECHO);
        tcsetattr(STDIN_FILENO, TCSANOW, &newSettings);
    }
    std::getline(std::cin, password);
    if (ttyAvailable) {
        tcsetattr(STDIN_FILENO, TCSANOW, &oldSettings);
        std::cout << std::endl;
    }
#endif
    return password;
}

bool AuthService::isValidUsername(const std::string& username) {
    if (username.size() < 3 || username.size() > 32) return false;
    return std::all_of(username.begin(), username.end(), [](unsigned char c) {
        return std::isalnum(c) || c == '_';
    });
}

bool AuthService::isValidEmail(const std::string& email) {
    auto at = email.find('@');
    auto dot = email.find_last_of('.');
    return at != std::string::npos && dot != std::string::npos && at > 0 &&
           dot > at + 1 && dot < email.size() - 1;
}

void AuthService::simulateSendOtp(const std::string& email, const std::string& code) {
    // ---- Swap this function body for a real provider call to make ----
    // ---- delivery real (e.g., an SMTP client or an SMS gateway API). --
    std::cout << "\n[Simulated email to " << email << "]\n";
    std::cout << "  Subject: Your SmartFinance verification code\n";
    std::cout << "  Your one-time code is: " << code << "  (valid ~30 seconds)\n\n";
    Logger::instance().info("AuthService", "OTP_SENT", "OTP dispatched (simulated) to " + email);
}

bool AuthService::runOtpChallenge(const std::string& totpSecret, const std::string& emailForDisplay) {
    Totp totp;
    std::cout << "Two-factor verification required.\n";
    std::cout << "  1) If you added this account to an authenticator app, enter the code it shows.\n";
    std::cout << "  2) Otherwise, press Enter with no code to have a demo code printed to this console.\n";

    for (int attempt = 1; attempt <= MAX_OTP_ATTEMPTS; ++attempt) {
        std::string input = promptLine("Enter 6-digit OTP (attempt " + std::to_string(attempt) +
                                         "/" + std::to_string(MAX_OTP_ATTEMPTS) + "), or leave blank to resend: ");
        if (input.empty()) {
            std::string code = totp.generate(totpSecret);
            simulateSendOtp(emailForDisplay, code);
            --attempt; // resending doesn't consume an attempt
            continue;
        }
        if (totp.verify(totpSecret, input)) {
            Logger::instance().info("AuthService", "OTP_VERIFIED", "OTP verified successfully");
            return true;
        }
        std::cout << "Incorrect or expired code.\n";
        Logger::instance().warn("AuthService", "OTP_FAILED", "Incorrect OTP entered (attempt " + std::to_string(attempt) + ")");
    }
    std::cout << "Too many incorrect attempts.\n";
    return false;
}

std::optional<UserRecord> AuthService::registerFlow() {
    auto& db = MySqlManager::instance();
    std::cout << "\n===== Register a New Account =====\n";

    std::string username;
    while (true) {
        username = promptLine("Choose a username (3-32 letters/digits/underscore): ");
        if (!isValidUsername(username)) {
            std::cout << "Invalid username format. Try again.\n";
            continue;
        }
        if (db.usernameExists(username)) {
            std::cout << "That username is already taken.\n";
            continue;
        }
        break;
    }

    std::string email;
    while (true) {
        email = promptLine("Email address: ");
        if (!isValidEmail(email)) {
            std::cout << "That doesn't look like a valid email. Try again.\n";
            continue;
        }
        if (db.emailExists(email)) {
            std::cout << "An account with that email already exists.\n";
            continue;
        }
        break;
    }

    std::string password;
    while (true) {
        password = promptPasswordMasked("Choose a password (min 8 characters): ");
        if (password.size() < 8) {
            std::cout << "Password must be at least 8 characters.\n";
            continue;
        }
        std::string confirm = promptPasswordMasked("Confirm password: ");
        if (password != confirm) {
            std::cout << "Passwords do not match. Try again.\n";
            continue;
        }
        break;
    }

    std::string salt = PasswordHasher::generateSalt();
    std::string passwordHash = PasswordHasher::hash(password, salt);
    std::string totpSecret = Totp::generateSecret();

    std::cout << "\n--- Two-Factor Authentication Setup ---\n";
    std::cout << "Secret (Base32): " << totpSecret << "\n";
    std::cout << "Add it to Google Authenticator / Authy via this URI (or type it in manually):\n";
    std::cout << "  " << Totp::provisioningUri(totpSecret, username, "SmartFinance") << "\n";
    std::cout << "(This is shown once. Store it somewhere safe.)\n\n";

    // First code sent immediately so registration can be verified without
    // requiring an authenticator app.
    simulateSendOtp(email, Totp().generate(totpSecret));

    if (!runOtpChallenge(totpSecret, email)) {
        std::cout << "Registration cancelled: OTP verification failed.\n";
        return std::nullopt;
    }

    if (!db.registerUser(username, email, passwordHash, salt, totpSecret)) {
        std::cout << "Registration failed: " << db.lastError() << "\n";
        return std::nullopt;
    }

    std::cout << "Account created. A dedicated database has been provisioned for '" << username << "'.\n";

    UserRecord record;
    record.username = username;
    record.email = email;
    record.passwordHash = passwordHash;
    record.passwordSalt = salt;
    record.totpSecret = totpSecret;
    return record;
}

std::optional<UserRecord> AuthService::loginFlow() {
    auto& db = MySqlManager::instance();
    std::cout << "\n===== Login =====\n";

    std::string username = promptLine("Username: ");
    auto userOpt = db.fetchUser(username);
    if (!userOpt.has_value()) {
        std::cout << "Invalid username or password.\n";
        Logger::instance().warn("AuthService", "LOGIN_FAILED", "Unknown username: " + username);
        return std::nullopt;
    }

    std::string password = promptPasswordMasked("Password: ");
    if (!PasswordHasher::verify(password, userOpt->passwordSalt, userOpt->passwordHash)) {
        std::cout << "Invalid username or password.\n";
        Logger::instance().warn("AuthService", "LOGIN_FAILED", "Incorrect password for: " + username);
        return std::nullopt;
    }

    Totp totp;
    simulateSendOtp(userOpt->email, totp.generate(userOpt->totpSecret));

    if (!runOtpChallenge(userOpt->totpSecret, userOpt->email)) {
        std::cout << "Login cancelled: OTP verification failed.\n";
        return std::nullopt;
    }

    Logger::instance().info("AuthService", "LOGIN_SUCCESS", "User logged in: " + username);
    return userOpt;
}

} // namespace sf
