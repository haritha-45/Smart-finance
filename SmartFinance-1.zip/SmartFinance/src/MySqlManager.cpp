#include "MySqlManager.h"
#include "Logger.h"
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <cctype>

namespace sf {

const std::string MySqlManager::MASTER_DB = "smartfinance_auth";
const std::string MySqlManager::USERS_TABLE = "users";

MySqlManager& MySqlManager::instance() {
    static MySqlManager mgr;
    return mgr;
}

MySqlManager::~MySqlManager() {
    disconnect();
}

void MySqlManager::disconnect() {
    if (conn_ != nullptr) {
        mysql_close(conn_);
        conn_ = nullptr;
    }
    connected_ = false;
}

void MySqlManager::setLastError(const std::string& context) {
    std::string detail = conn_ != nullptr ? mysql_error(conn_) : "no connection";
    lastError_ = context + ": " + detail;
    Logger::instance().error("MySqlManager", "DB_ERROR", lastError_);
}

bool MySqlManager::connect(const std::string& host, const std::string& user,
                             const std::string& password, unsigned int port) {
    conn_ = mysql_init(nullptr);
    if (conn_ == nullptr) {
        lastError_ = "mysql_init failed (out of memory)";
        return false;
    }

    // No default schema is selected here -- each SQL statement below
    // qualifies its target explicitly (`USE <db>` or `<db>.<table>`),
    // since a single connection moves between the master database and
    // whichever user's personal database is active.
    MYSQL* result = mysql_real_connect(conn_, host.c_str(), user.c_str(),
                                         password.c_str(), nullptr, port, nullptr, 0);
    if (result == nullptr) {
        setLastError("mysql_real_connect failed");
        mysql_close(conn_);
        conn_ = nullptr;
        return false;
    }

    mysql_set_character_set(conn_, "utf8mb4");
    connected_ = true;

    if (!ensureMasterSchema()) {
        disconnect();
        return false;
    }

    Logger::instance().info("MySqlManager", "DB_CONNECTED",
        "Connected to MySQL server at " + host + ":" + std::to_string(port));
    return true;
}

bool MySqlManager::execute(const std::string& sql) {
    if (conn_ == nullptr) {
        lastError_ = "not connected";
        return false;
    }
    if (mysql_query(conn_, sql.c_str()) != 0) {
        setLastError("query failed [" + sql + "]");
        return false;
    }
    return true;
}

std::string MySqlManager::escape(const std::string& value) const {
    std::vector<char> buffer(value.size() * 2 + 1);
    unsigned long len = mysql_real_escape_string(conn_, buffer.data(), value.c_str(),
                                                   static_cast<unsigned long>(value.size()));
    return std::string(buffer.data(), len);
}

std::string MySqlManager::sanitizeIdentifier(const std::string& raw) {
    std::string result;
    result.reserve(raw.size());
    for (char c : raw) {
        char lc = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        if (std::isalnum(static_cast<unsigned char>(lc))) {
            result += lc;
        } else {
            result += '_';
        }
    }
    if (result.empty() || std::isdigit(static_cast<unsigned char>(result[0]))) {
        result = "u_" + result;
    }
    return result;
}

bool MySqlManager::ensureMasterSchema() {
    if (!execute("CREATE DATABASE IF NOT EXISTS `" + MASTER_DB +
                  "` CHARACTER SET utf8mb4")) {
        return false;
    }
    if (!execute("USE `" + MASTER_DB + "`")) {
        return false;
    }
    std::string createUsers =
        "CREATE TABLE IF NOT EXISTS `" + USERS_TABLE + "` ("
        "id INT AUTO_INCREMENT PRIMARY KEY, "
        "username VARCHAR(64) NOT NULL UNIQUE, "
        "email VARCHAR(128) NOT NULL UNIQUE, "
        "password_hash CHAR(64) NOT NULL, "
        "password_salt VARCHAR(64) NOT NULL, "
        "totp_secret VARCHAR(64) NOT NULL, "
        "created_at DATETIME DEFAULT CURRENT_TIMESTAMP"
        ") ENGINE=InnoDB CHARACTER SET utf8mb4";
    return execute(createUsers);
}

bool MySqlManager::usernameExists(const std::string& username) {
    if (!execute("USE `" + MASTER_DB + "`")) return false;
    std::string sql = "SELECT id FROM `" + USERS_TABLE + "` WHERE username = '" +
                       escape(username) + "' LIMIT 1";
    if (!execute(sql)) return false;

    MYSQL_RES* res = mysql_store_result(conn_);
    if (res == nullptr) return false;
    bool exists = mysql_num_rows(res) > 0;
    mysql_free_result(res);
    return exists;
}

bool MySqlManager::emailExists(const std::string& email) {
    if (!execute("USE `" + MASTER_DB + "`")) return false;
    std::string sql = "SELECT id FROM `" + USERS_TABLE + "` WHERE email = '" +
                       escape(email) + "' LIMIT 1";
    if (!execute(sql)) return false;

    MYSQL_RES* res = mysql_store_result(conn_);
    if (res == nullptr) return false;
    bool exists = mysql_num_rows(res) > 0;
    mysql_free_result(res);
    return exists;
}

bool MySqlManager::registerUser(const std::string& username, const std::string& email,
                                  const std::string& passwordHash, const std::string& passwordSalt,
                                  const std::string& totpSecret) {
    if (!execute("USE `" + MASTER_DB + "`")) return false;

    std::string sql = "INSERT INTO `" + USERS_TABLE +
        "` (username, email, password_hash, password_salt, totp_secret) VALUES ('" +
        escape(username) + "', '" + escape(email) + "', '" + escape(passwordHash) + "', '" +
        escape(passwordSalt) + "', '" + escape(totpSecret) + "')";

    if (!execute(sql)) return false;

    // Every login gets its own database and its own table, isolated from
    // every other user's data.
    std::string dbName = "sf_" + sanitizeIdentifier(username);
    std::string tableName = "transactions_" + sanitizeIdentifier(username);

    if (!execute("CREATE DATABASE IF NOT EXISTS `" + dbName + "` CHARACTER SET utf8mb4")) {
        return false;
    }
    if (!execute("USE `" + dbName + "`")) {
        return false;
    }
    std::string createTable =
        "CREATE TABLE IF NOT EXISTS `" + tableName + "` ("
        "id INT AUTO_INCREMENT PRIMARY KEY, "
        "txn_date DATE NOT NULL, "
        "txn_type VARCHAR(10) NOT NULL, "
        "amount DECIMAL(12,2) NOT NULL, "
        "category VARCHAR(64) NOT NULL, "
        "description VARCHAR(255), "
        "created_at DATETIME DEFAULT CURRENT_TIMESTAMP"
        ") ENGINE=InnoDB CHARACTER SET utf8mb4";
    if (!execute(createTable)) {
        return false;
    }

    Logger::instance().info("MySqlManager", "USER_REGISTERED",
        "Created database '" + dbName + "' and table '" + tableName + "' for user '" + username + "'");
    return true;
}

std::optional<UserRecord> MySqlManager::fetchUser(const std::string& username) {
    if (!execute("USE `" + MASTER_DB + "`")) return std::nullopt;

    std::string sql = "SELECT id, username, email, password_hash, password_salt, totp_secret FROM `" +
                       USERS_TABLE + "` WHERE username = '" + escape(username) + "' LIMIT 1";
    if (!execute(sql)) return std::nullopt;

    MYSQL_RES* res = mysql_store_result(conn_);
    if (res == nullptr) return std::nullopt;

    MYSQL_ROW row = mysql_fetch_row(res);
    if (row == nullptr) {
        mysql_free_result(res);
        return std::nullopt;
    }

    UserRecord record;
    record.id = std::atoi(row[0]);
    record.username = row[1] ? row[1] : "";
    record.email = row[2] ? row[2] : "";
    record.passwordHash = row[3] ? row[3] : "";
    record.passwordSalt = row[4] ? row[4] : "";
    record.totpSecret = row[5] ? row[5] : "";

    mysql_free_result(res);
    return record;
}

bool MySqlManager::insertTransaction(const std::string& username, const std::string& date,
                                       const std::string& txnType, double amount,
                                       const std::string& category, const std::string& description) {
    std::string dbName = "sf_" + sanitizeIdentifier(username);
    std::string tableName = "transactions_" + sanitizeIdentifier(username);

    if (!execute("USE `" + dbName + "`")) return false;

    char amountBuf[64];
    std::snprintf(amountBuf, sizeof(amountBuf), "%.2f", amount);

    std::string sql = "INSERT INTO `" + tableName +
        "` (txn_date, txn_type, amount, category, description) VALUES ('" +
        escape(date) + "', '" + escape(txnType) + "', " + amountBuf + ", '" +
        escape(category) + "', '" + escape(description) + "')";

    return execute(sql);
}

std::vector<TransactionRecord> MySqlManager::fetchTransactions(const std::string& username) {
    std::vector<TransactionRecord> results;
    std::string dbName = "sf_" + sanitizeIdentifier(username);
    std::string tableName = "transactions_" + sanitizeIdentifier(username);

    if (!execute("USE `" + dbName + "`")) return results;

    std::string sql = "SELECT id, txn_date, txn_type, amount, category, description FROM `" +
                       tableName + "` ORDER BY txn_date, id";
    if (!execute(sql)) return results;

    MYSQL_RES* res = mysql_store_result(conn_);
    if (res == nullptr) return results;

    MYSQL_ROW row;
    while ((row = mysql_fetch_row(res)) != nullptr) {
        TransactionRecord rec;
        rec.id = std::atoi(row[0]);
        rec.date = row[1] ? row[1] : "";
        rec.txnType = row[2] ? row[2] : "";
        rec.amount = row[3] ? std::atof(row[3]) : 0.0;
        rec.category = row[4] ? row[4] : "";
        rec.description = row[5] ? row[5] : "";
        results.push_back(rec);
    }
    mysql_free_result(res);
    return results;
}

} // namespace sf
