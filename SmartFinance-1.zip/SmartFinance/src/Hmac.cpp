#include "Hmac.h"
#include "Sha1.h"

namespace sf {

namespace {
    constexpr size_t BLOCK_SIZE = 64; // SHA-1 block size in bytes
}

std::vector<uint8_t> Hmac::sha1(const std::vector<uint8_t>& key, const std::vector<uint8_t>& message) {
    std::vector<uint8_t> k = key;

    // Keys longer than the block size are hashed down first (RFC 2104).
    if (k.size() > BLOCK_SIZE) {
        k = Sha1::digest(k);
    }
    // Keys shorter than the block size are zero-padded.
    k.resize(BLOCK_SIZE, 0x00);

    std::vector<uint8_t> oKeyPad(BLOCK_SIZE), iKeyPad(BLOCK_SIZE);
    for (size_t i = 0; i < BLOCK_SIZE; ++i) {
        oKeyPad[i] = k[i] ^ 0x5C;
        iKeyPad[i] = k[i] ^ 0x36;
    }

    std::vector<uint8_t> inner = iKeyPad;
    inner.insert(inner.end(), message.begin(), message.end());
    std::vector<uint8_t> innerHash = Sha1::digest(inner);

    std::vector<uint8_t> outer = oKeyPad;
    outer.insert(outer.end(), innerHash.begin(), innerHash.end());
    return Sha1::digest(outer);
}

} // namespace sf
