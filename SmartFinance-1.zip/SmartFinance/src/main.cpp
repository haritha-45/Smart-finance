// main.cpp
// Console entry point. Connects to MySQL, then offers Register / Login
// (both gated by a TOTP one-time code), and on successful login drops
// the user into a finance session backed entirely by their own
// dedicated MySQL database and table (see MySqlManager.h).

#include <iostream>
#include <iomanip>
#include <limits>
#include <cstdlib>
#include <map>
#include <ctime>
#include <sstream>

#include "Logger.h"
#include "MySqlManager.h"
#include "AuthService.h"
#include "Budget.h"
#include "MonthlyPlan.h"
#include "RecommendationEngine.h"
#include "AlertManager.h"
#include "InvestmentAnalyzer.h"

using namespace sf;

namespace {

std::string envOr(const char* name, const std::string& fallback) {
    const char* v = std::getenv(name);
    return v != nullptr ? std::string(v) : fallback;
}

std::string todayIso() {
    std::time_t t = std::time(nullptr);
    std::tm tmBuf{};
#if defined(_WIN32)
    localtime_s(&tmBuf, &t);
#else
    localtime_r(&t, &tmBuf);
#endif
    std::ostringstream oss;
    oss << std::put_time(&tmBuf, "%Y-%m-%d");
    return oss.str();
}

std::string prompt(const std::string& text) {
    std::cout << text;
    std::string line;
    std::getline(std::cin, line);
    return line;
}

double promptDouble(const std::string& text) {
    while (true) {
        std::string line = prompt(text);
        try {
            size_t pos;
            double val = std::stod(line, &pos);
            if (pos == line.size() && val >= 0.0) return val;
        } catch (...) {}
        std::cout << "Please enter a valid non-negative number.\n";
    }
}

bool connectToMySql() {
    std::string host = envOr("MYSQL_HOST", "127.0.0.1");
    std::string user = envOr("MYSQL_USER", "root");
    std::string password = envOr("MYSQL_PASSWORD", "");
    unsigned int port = 3306;
    try {
        port = static_cast<unsigned int>(std::stoi(envOr("MYSQL_PORT", "3306")));
    } catch (...) {
        std::cout << "Warning: MYSQL_PORT is not a valid number; defaulting to 3306.\n";
    }

    for (int attempt = 1; attempt <= 3; ++attempt) {
        std::cout << "Connecting to MySQL at " << host << ":" << port << " as '" << user << "'...\n";
        if (MySqlManager::instance().connect(host, user, password, port)) {
            std::cout << "Connected.\n";
            return true;
        }
        std::cout << "Connection failed: " << MySqlManager::instance().lastError() << "\n";
        if (attempt == 3) break;

        std::cout << "\nEnter connection details (or press Enter to keep the current value).\n";
        std::string h = prompt("Host [" + host + "]: ");
        if (!h.empty()) host = h;
        std::string u = prompt("User [" + user + "]: ");
        if (!u.empty()) user = u;
        std::string p = prompt("Password (visible in this retry prompt): ");
        if (!p.empty()) password = p;
        std::string portStr = prompt("Port [" + std::to_string(port) + "]: ");
        if (!portStr.empty()) {
            try { port = static_cast<unsigned int>(std::stoi(portStr)); } catch (...) {}
        }
    }
    return false;
}

void printTransactions(const std::vector<TransactionRecord>& txns) {
    if (txns.empty()) {
        std::cout << "(no transactions yet)\n";
        return;
    }
    std::cout << std::left
               << std::setw(6) << "ID" << std::setw(12) << "Date" << std::setw(10) << "Type"
               << std::setw(12) << "Amount" << std::setw(16) << "Category" << "Description\n";
    std::cout << std::string(70, '-') << "\n";
    double totalIncome = 0.0, totalExpense = 0.0;
    for (const auto& t : txns) {
        std::cout << std::left << std::setw(6) << t.id << std::setw(12) << t.date
                   << std::setw(10) << t.txnType << std::setw(12) << std::fixed << std::setprecision(2)
                   << t.amount << std::setw(16) << t.category << t.description << "\n";
        if (t.txnType == "Income") totalIncome += t.amount; else totalExpense += t.amount;
    }
    std::cout << std::string(70, '-') << "\n";
    std::cout << "Total Income: Rs " << totalIncome << "   Total Expense: Rs " << totalExpense
               << "   Net: Rs " << (totalIncome - totalExpense) << "\n";
}

Budget rebuildBudgetFromHistory(const std::string& username, double salary, double fixedExpenses,
                                  double savingsTarget) {
    MonthlyPlan plan(1, todayIso().substr(0, 7), salary, fixedExpenses, 0.0);
    auto weights = RecommendationEngine::recommendCategoryWeights(nullptr);
    Budget budget = plan.generatePlan(weights, savingsTarget);

    // Replay this user's persisted expenses so alerts reflect real history,
    // not just what happens during this session.
    for (const auto& t : MySqlManager::instance().fetchTransactions(username)) {
        if (t.txnType == "Expense") {
            Expense e(t.id, t.date, t.amount, t.description, t.category, "Unknown");
            budget.recordSpend(e);
        }
    }
    return budget;
}

void financeSession(const UserRecord& user) {
    std::cout << "\nWelcome, " << user.username << "! Your data lives in its own database "
               << "(sf_" << MySqlManager::sanitizeIdentifier(user.username) << ").\n";

    double salary = promptDouble("Monthly salary for this session: Rs ");
    double fixedExpenses = promptDouble("Known fixed expenses this month: Rs ");
    double savingsTarget = promptDouble("Savings target this month: Rs ");

    Budget budget = rebuildBudgetFromHistory(user.username, salary, fixedExpenses, savingsTarget);

    bool loggedIn = true;
    while (loggedIn) {
        std::cout << "\n--- " << user.username << "'s Finance Menu ---\n"
                   << "1. Add Expense\n"
                   << "2. Add Income (salary / additional)\n"
                   << "3. View Transaction History\n"
                   << "4. View Budget Status & Alerts\n"
                   << "5. Get Investment Suggestion\n"
                   << "6. Logout\n";
        std::string choice = prompt("Choose an option: ");

        if (choice == "1") {
            std::string category = prompt("Category (e.g., Groceries, Dining, Transport): ");
            double amount = promptDouble("Amount: Rs ");
            std::string description = prompt("Description: ");
            Expense e(0, todayIso(), amount, description, category, "Cash/Card");
            if (!e.validate()) {
                std::cout << "Invalid expense (amount must be positive).\n";
                continue;
            }
            budget.recordSpend(e);
            if (MySqlManager::instance().insertTransaction(user.username, todayIso(), "Expense",
                                                              amount, category, description)) {
                std::cout << "Expense recorded.\n";
            } else {
                std::cout << "Failed to save expense: " << MySqlManager::instance().lastError() << "\n";
            }
            for (const auto& alert : AlertManager::evaluateBudget(budget)) {
                AlertManager::deliver(alert);
            }

        } else if (choice == "2") {
            std::string source = prompt("Source (e.g., Employer, Freelance): ");
            double amount = promptDouble("Amount: Rs ");
            std::string additionalAns = prompt("Is this additional (mid-month) income? (y/n): ");
            bool isAdditional = !additionalAns.empty() && (additionalAns[0] == 'y' || additionalAns[0] == 'Y');

            if (MySqlManager::instance().insertTransaction(user.username, todayIso(), "Income",
                                                              amount, source, isAdditional ? "Additional income" : "Salary")) {
                std::cout << "Income recorded.\n";
            } else {
                std::cout << "Failed to save income: " << MySqlManager::instance().lastError() << "\n";
            }

            if (isAdditional) {
                std::cout << "Recommended allocation for this additional income:\n";
                auto allocation = RecommendationEngine::recommendAllocation(amount);
                for (const auto& [bucket, amt] : allocation) {
                    std::cout << "  - " << bucket << ": Rs " << std::fixed << std::setprecision(2) << amt << "\n";
                }
            }

        } else if (choice == "3") {
            auto txns = MySqlManager::instance().fetchTransactions(user.username);
            printTransactions(txns);

        } else if (choice == "4") {
            std::cout << "\nBudget status:\n";
            for (const auto& [category, limit] : budget.limits()) {
                std::cout << "  - " << category << ": Rs " << std::fixed << std::setprecision(2)
                           << budget.getSpent(category) << " / Rs " << limit;
                if (budget.isExceeded(category)) std::cout << "  [EXCEEDED]";
                else if (budget.isApproachingLimit(category)) std::cout << "  [WARNING]";
                std::cout << "\n";
            }
            auto alerts = AlertManager::evaluateBudget(budget);
            if (alerts.empty()) {
                std::cout << "No active alerts.\n";
            } else {
                for (const auto& alert : alerts) AlertManager::deliver(alert);
            }

        } else if (choice == "5") {
            double surplus = budget.totalLimit() - budget.totalSpent();
            std::cout << InvestmentAnalyzer::suggest(RiskLevel::MEDIUM, surplus > 0 ? surplus : 0.0) << "\n";

        } else if (choice == "6") {
            std::cout << "Logging out " << user.username << ".\n";
            Logger::instance().info("System", "LOGOUT", "User logged out: " + user.username);
            loggedIn = false;

        } else {
            std::cout << "Unrecognized option.\n";
        }
    }
}

} // namespace

int main() {
    std::cout << std::fixed << std::setprecision(2);
    Logger::instance().info("System", "APP_START", "Application started.");

    std::cout << "===== Smart Personal Finance Management and Financial Intelligence System =====\n";

    if (!connectToMySql()) {
        std::cerr << "Could not connect to MySQL. Set MYSQL_HOST / MYSQL_USER / MYSQL_PASSWORD / "
                      "MYSQL_PORT environment variables, or check that the server is running.\n";
        return 1;
    }

    bool running = true;
    while (running) {
        std::cout << "\n===== Main Menu =====\n"
                   << "1. Register\n"
                   << "2. Login\n"
                   << "3. Exit\n";
        std::string choice = prompt("Choose an option: ");

        if (choice == "1") {
            auto record = AuthService::registerFlow();
            if (record.has_value()) {
                financeSession(*record);
            }
        } else if (choice == "2") {
            auto record = AuthService::loginFlow();
            if (record.has_value()) {
                financeSession(*record);
            }
        } else if (choice == "3") {
            running = false;
        } else {
            std::cout << "Unrecognized option.\n";
        }
    }

    std::cout << "Goodbye.\n";
    Logger::instance().info("System", "APP_END", "Application completed successfully.");
    return 0;
}
