#include "PasswordHasher.h"
#include "Sha256.h"
#include <random>
#include <sstream>
#include <iomanip>

namespace sf {

std::string PasswordHasher::generateSalt(size_t byteLength) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dist(0, 255);

    std::ostringstream oss;
    for (size_t i = 0; i < byteLength; ++i) {
        oss << std::hex << std::setw(2) << std::setfill('0') << dist(gen);
    }
    return oss.str();
}

std::string PasswordHasher::hash(const std::string& password, const std::string& salt) {
    return Sha256::hexDigest(salt + password);
}

bool PasswordHasher::verify(const std::string& password, const std::string& salt, const std::string& expectedHash) {
    return hash(password, salt) == expectedHash;
}

} // namespace sf
