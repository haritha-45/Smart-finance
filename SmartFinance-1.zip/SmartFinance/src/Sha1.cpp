#include "Sha1.h"
#include <cstring>
#include <sstream>
#include <iomanip>

namespace sf {

uint32_t Sha1::leftRotate(uint32_t value, uint32_t bits) {
    return (value << bits) | (value >> (32 - bits));
}

std::vector<uint8_t> Sha1::digest(const std::vector<uint8_t>& data) {
    uint32_t h0 = 0x67452301;
    uint32_t h1 = 0xEFCDAB89;
    uint32_t h2 = 0x98BADCFE;
    uint32_t h3 = 0x10325476;
    uint32_t h4 = 0xC3D2E1F0;

    uint64_t originalBitLen = static_cast<uint64_t>(data.size()) * 8;

    std::vector<uint8_t> msg(data.begin(), data.end());
    msg.push_back(0x80);
    while (msg.size() % 64 != 56) {
        msg.push_back(0x00);
    }
    for (int i = 7; i >= 0; --i) {
        msg.push_back(static_cast<uint8_t>((originalBitLen >> (i * 8)) & 0xFF));
    }

    for (size_t chunkStart = 0; chunkStart < msg.size(); chunkStart += 64) {
        uint32_t w[80];
        for (int i = 0; i < 16; ++i) {
            w[i] = (static_cast<uint32_t>(msg[chunkStart + i * 4]) << 24) |
                   (static_cast<uint32_t>(msg[chunkStart + i * 4 + 1]) << 16) |
                   (static_cast<uint32_t>(msg[chunkStart + i * 4 + 2]) << 8) |
                   (static_cast<uint32_t>(msg[chunkStart + i * 4 + 3]));
        }
        for (int i = 16; i < 80; ++i) {
            w[i] = leftRotate(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1);
        }

        uint32_t a = h0, b = h1, c = h2, d = h3, e = h4;

        for (int i = 0; i < 80; ++i) {
            uint32_t f, k;
            if (i < 20) {
                f = (b & c) | ((~b) & d);
                k = 0x5A827999;
            } else if (i < 40) {
                f = b ^ c ^ d;
                k = 0x6ED9EBA1;
            } else if (i < 60) {
                f = (b & c) | (b & d) | (c & d);
                k = 0x8F1BBCDC;
            } else {
                f = b ^ c ^ d;
                k = 0xCA62C1D6;
            }
            uint32_t temp = leftRotate(a, 5) + f + e + k + w[i];
            e = d;
            d = c;
            c = leftRotate(b, 30);
            b = a;
            a = temp;
        }

        h0 += a; h1 += b; h2 += c; h3 += d; h4 += e;
    }

    std::vector<uint8_t> result(20);
    uint32_t hs[5] = { h0, h1, h2, h3, h4 };
    for (int i = 0; i < 5; ++i) {
        result[i * 4]     = static_cast<uint8_t>((hs[i] >> 24) & 0xFF);
        result[i * 4 + 1] = static_cast<uint8_t>((hs[i] >> 16) & 0xFF);
        result[i * 4 + 2] = static_cast<uint8_t>((hs[i] >> 8) & 0xFF);
        result[i * 4 + 3] = static_cast<uint8_t>(hs[i] & 0xFF);
    }
    return result;
}

std::vector<uint8_t> Sha1::digest(const std::string& data) {
    return digest(std::vector<uint8_t>(data.begin(), data.end()));
}

std::string Sha1::hexDigest(const std::string& data) {
    auto bytes = digest(data);
    std::ostringstream oss;
    for (uint8_t b : bytes) {
        oss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(b);
    }
    return oss.str();
}

} // namespace sf
