# SmartFinance

Smart Personal Finance Management and Financial Intelligence System (C++17),
console-based, backed by a real MySQL server. Every registered user gets
their own dedicated MySQL **database** and their own dedicated
**transactions table** inside it -- no two users' data ever shares a table.
Registration and login both require a **TOTP** one-time code (RFC 6238,
the same standard Google Authenticator/Authy use), in addition to a
password.

## 1. Prerequisites

- A C++17 compiler (g++ or clang++) and GNU Make
- A running MySQL server (5.7+/8.0+) or MariaDB, reachable from this machine
- The MySQL **client development** package (headers + `libmysqlclient`),
  which is separate from just having a MySQL server or the `mysql` CLI
  installed:

  | Platform | Install command |
  |---|---|
  | Ubuntu / Debian | `sudo apt install libmysqlclient-dev` |
  | Fedora / RHEL | `sudo dnf install mysql-devel` (or `community-mysql-devel`) |
  | Arch | `sudo pacman -S mariadb-libs` |
  | macOS (Homebrew) | `brew install mysql-client` and add its `bin/` to `PATH` (brew prints the exact export line after install) |
  | Windows | Install "MySQL Server" via the MySQL Installer, which includes Connector/C, **or** use WSL and follow the Ubuntu steps |

  If this package is missing, `make` fails immediately with:
  `fatal error: mysql/mysql.h: No such file or directory` -- that error
  means exactly one thing: install the package above and try again.

## 2. Configure the database connection

The program reads connection details from environment variables (with
defaults shown):

| Variable | Default | Meaning |
|---|---|---|
| `MYSQL_HOST` | `127.0.0.1` | MySQL server host |
| `MYSQL_USER` | `root` | MySQL user |
| `MYSQL_PASSWORD` | *(empty)* | MySQL password |
| `MYSQL_PORT` | `3306` | MySQL port |

Example:

```bash
export MYSQL_HOST=127.0.0.1
export MYSQL_USER=root
export MYSQL_PASSWORD=your_mysql_password
export MYSQL_PORT=3306
```

If the connection fails on launch, the program also prompts interactively
for these values (up to 3 attempts) before giving up.

The connecting MySQL user needs `CREATE DATABASE` / `CREATE TABLE`
privileges, since the program creates a new database per registered user.
A local `root` account (or any account with global `CREATE` privileges)
is the simplest choice for development.

## 3. Build and run

```bash
make          # compiles bin/smartfinance
make run      # builds, then runs it
```

`make printvars` shows the MySQL compiler/linker flags the build detected
(via `mysql_config`), which is the first thing to check if the build
fails with MySQL-related errors.

## 4. Using the program

```
===== Main Menu =====
1. Register
2. Login
3. Exit
```

**Register** walks you through: username, email, password (entered
masked), then two-factor setup. You'll see a Base32 secret and an
`otpauth://` URI -- scan/enter that into Google Authenticator, Authy, or
similar for real authenticator-app-based codes on every future login.
For trying the program without an authenticator app, press Enter at the
OTP prompt with nothing typed and the current code is printed to the
console instead (clearly labeled `[Simulated email to ...]` -- see the
note below).

**Login** asks for username, password, then the same TOTP challenge.

Once inside, the per-user Finance Menu lets you record expenses and
income (persisted immediately to *your* MySQL database), view your
transaction history, check budget status and alerts, and get an
investment suggestion.

## 5. How the pieces fit together

| Module | Files | Role |
|---|---|---|
| Sha1 | Sha1.h/.cpp | RFC 3174 SHA-1 (used only inside HMAC for TOTP) |
| Hmac | Hmac.h/.cpp | RFC 2104 HMAC-SHA1 |
| Base32 | Base32.h/.cpp | RFC 4648 Base32 (TOTP secret encoding) |
| Totp | Totp.h/.cpp | RFC 6238 TOTP generate/verify + secret/URI generation |
| Sha256 | Sha256.h/.cpp | FIPS 180-4 SHA-256 (password hashing) |
| PasswordHasher | PasswordHasher.h/.cpp | Salted SHA-256 password hashing |
| MySqlManager | MySqlManager.h/.cpp | Master auth DB + per-user DB/table creation and access |
| AuthService | AuthService.h/.cpp | Console register/login flows, OTP challenge, masked password input |
| Transaction/Income/Expense | *.h/.cpp | Financial transaction model |
| Budget, MonthlyPlan | *.h/.cpp | Category budgeting and plan generation |
| RecommendationEngine, AlertManager, InvestmentAnalyzer | *.h/.cpp | Recommendations, budget alerts, investment suggestions |
| Report, SavingsManager, EmergencyFundManager, DatabaseManager, User | *.h/.cpp | Retained from the original design (see note below) |

**Note on legacy modules:** `User.h/.cpp` and `DatabaseManager.h/.cpp`
were the original (pre-MySQL) login and flat-file persistence classes.
They still compile and are harmless, but `main.cpp` no longer calls them
-- `AuthService` + `MySqlManager` now own authentication and persistence.
`Report.h/.cpp`, `SavingsManager.h/.cpp`, and `EmergencyFundManager.h/.cpp`
are also not currently wired into the console menu (the menu focuses on
the newly-requested MySQL+OTP flow); they compile standalone and can be
reconnected the same way `Budget`/`AlertManager`/`RecommendationEngine`
are.

## 6. On "sending" the OTP

A real deployment would email or text the code via a provider (SMTP,
Twilio/SNS, etc.), which needs network access and account credentials
this project doesn't have. Two paths exist here instead, both using the
*same* real, RFC-6238-correct TOTP underneath:

1. **Authenticator app** (recommended, and works fully offline from this
   program's perspective): scan/enter the secret shown once at
   registration into Google Authenticator or similar; it computes the
   same codes this program verifies.
2. **Console-simulated delivery**: `AuthService::simulateSendOtp()`
   prints the code to the console instead of emailing it, clearly
   labeled `[Simulated email to ...]`. Replace the body of that one
   function with a real SMTP/SMS API call to make delivery real; nothing
   else in the TOTP/auth logic needs to change.

## 7. Security notes (read before using this for anything real)

- Password hashing is salted SHA-256, not a slow password KDF
  (bcrypt/scrypt/Argon2). SHA-256 is fast, which is a *liability* for
  password storage since it makes brute-forcing leaked hashes cheaper.
  Swap `PasswordHasher` for a real KDF before using this beyond a demo.
- SQL values are escaped with `mysql_real_escape_string`; SQL identifiers
  (database/table names derived from usernames) are restricted to a
  whitelist charset (`MySqlManager::sanitizeIdentifier`) rather than
  escaped, since MySQL has no parameter-binding for identifiers.
- The MySQL password is read as plain text if you type it at the
  interactive connection retry prompt (there's no masking there, unlike
  the account password prompts) -- prefer the environment variable.
- This is a reference/demo implementation, not an audited security
  product.
