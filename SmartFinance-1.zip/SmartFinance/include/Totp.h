#ifndef SMARTFINANCE_TOTP_H
#define SMARTFINANCE_TOTP_H

#include <string>
#include <cstdint>

namespace sf {

// Time-based One-Time Password generator/verifier (RFC 6238), built on
// HMAC-SHA1 (RFC 2104) and HOTP (RFC 4226). Compatible with standard
// authenticator apps (Google Authenticator, Authy, Microsoft
// Authenticator, etc.) when the Base32 secret is entered or scanned there.
class Totp {
public:
    // stepSeconds: the time-step size (30s is the near-universal default).
    // digits: length of the generated code (6 is the near-universal default).
    explicit Totp(int stepSeconds = 30, int digits = 6);

    // Generates the TOTP code for the given Base32-encoded secret at the
    // given Unix timestamp (defaults to "now").
    std::string generate(const std::string& base32Secret, int64_t unixTime = -1) const;

    // Verifies a user-entered code, allowing +/- `window` time steps of
    // drift (default 1 step = up to ~30s of clock skew in each direction).
    bool verify(const std::string& base32Secret, const std::string& code, int window = 1) const;

    // Generates a random Base32-encoded secret suitable for a new account
    // (20 raw bytes = 160 bits, the RFC 4226 recommended HOTP key length).
    static std::string generateSecret(size_t byteLength = 20);

    // Builds an otpauth:// provisioning URI, the standard string that a
    // QR code would encode for scanning into an authenticator app.
    static std::string provisioningUri(const std::string& base32Secret,
                                         const std::string& accountName,
                                         const std::string& issuer);

private:
    int stepSeconds_;
    int digits_;

    static std::string urlEncode(const std::string& value);
};

} // namespace sf

#endif // SMARTFINANCE_TOTP_H
