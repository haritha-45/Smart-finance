#ifndef SMARTFINANCE_MYSQLMANAGER_H
#define SMARTFINANCE_MYSQLMANAGER_H

#include <string>
#include <vector>
#include <optional>
#include <mysql/mysql.h>

namespace sf {

// A single stored transaction row, as read back from a user's personal
// MySQL table.
struct TransactionRecord {
    int id;
    std::string date;
    std::string txnType;   // "Income" or "Expense"
    double amount;
    std::string category;  // category for Expense, source for Income
    std::string description;
};

// A user's authentication record, as stored in the shared master database.
struct UserRecord {
    int id;
    std::string username;
    std::string email;
    std::string passwordHash;
    std::string passwordSalt;
    std::string totpSecret;
};

// MySqlManager
// Database Access Layer backed by a real MySQL server, using the MySQL
// C API (libmysqlclient).
//
// Design, per the requirement that every login gets its own database and
// table:
//   - One shared master database ("smartfinance_auth") holds a single
//     `users` table used only for authentication lookups (it has to live
//     somewhere reachable before a user's personal database exists).
//   - On successful registration, a brand-new database named
//     `sf_<username>` is created for that user, containing a table named
//     `transactions_<username>` that only that user's data ever touches.
//     No two users' financial data share a table or a database.
//
// This class issues plain SQL text via mysql_query(), escaping every
// free-text value with mysql_real_escape_string() and validating every
// identifier (database/table names built from the username) against a
// strict whitelist, since MySQL does not support parameter binding for
// identifiers. Numeric values are formatted with snprintf, never
// interpolated from unescaped user text.
class MySqlManager {
public:
    static MySqlManager& instance();

    // Connects to the MySQL server (no default schema selected yet) and
    // ensures the master auth database/table exist. Returns false and
    // sets lastError() on failure.
    bool connect(const std::string& host, const std::string& user,
                 const std::string& password, unsigned int port = 3306);

    bool isConnected() const { return connected_; }
    const std::string& lastError() const { return lastError_; }

    void disconnect();

    // ---- Master (auth) database operations ----
    bool usernameExists(const std::string& username);
    bool emailExists(const std::string& email);

    // Inserts the auth record AND creates the user's personal database
    // and transactions table. Returns false (leaving nothing partially
    // created where avoidable) on any failure.
    bool registerUser(const std::string& username, const std::string& email,
                       const std::string& passwordHash, const std::string& passwordSalt,
                       const std::string& totpSecret);

    std::optional<UserRecord> fetchUser(const std::string& username);

    // ---- Per-user database operations ----
    bool insertTransaction(const std::string& username, const std::string& date,
                            const std::string& txnType, double amount,
                            const std::string& category, const std::string& description);

    std::vector<TransactionRecord> fetchTransactions(const std::string& username);

    // Converts a username into a safe SQL identifier fragment: lowercase
    // ASCII letters, digits, and underscore only, guaranteed to start
    // with a letter. Two different usernames can never collide onto the
    // same sanitized identifier being treated as authoritative, because
    // usernames themselves are required to already satisfy this charset
    // at registration time (see AuthService::isValidUsername).
    static std::string sanitizeIdentifier(const std::string& raw);

private:
    MySqlManager() = default;
    ~MySqlManager();
    MySqlManager(const MySqlManager&) = delete;
    MySqlManager& operator=(const MySqlManager&) = delete;

    bool ensureMasterSchema();
    bool execute(const std::string& sql);
    std::string escape(const std::string& value) const;
    void setLastError(const std::string& context);

    MYSQL* conn_ = nullptr;
    bool connected_ = false;
    std::string lastError_;

    static const std::string MASTER_DB;
    static const std::string USERS_TABLE;
};

} // namespace sf

#endif // SMARTFINANCE_MYSQLMANAGER_H
