#ifndef SMARTFINANCE_SHA1_H
#define SMARTFINANCE_SHA1_H

#include <string>
#include <cstdint>
#include <vector>

namespace sf {

// Minimal, dependency-free SHA-1 implementation (RFC 3174).
//
// SHA-1 is no longer recommended for new cryptographic designs, but it is
// what RFC 6238 (TOTP) and RFC 4226 (HOTP) specify as the default HMAC
// hash for one-time-password generation, and is what virtually every
// authenticator app (Google Authenticator, Authy, etc.) expects. It is
// used here ONLY as the hash inside HMAC-SHA1 for TOTP -- password
// storage uses SHA-256 instead (see Sha256.h).
class Sha1 {
public:
    // Returns the 20-byte raw digest of `data`.
    static std::vector<uint8_t> digest(const std::vector<uint8_t>& data);

    // Convenience overload for string input.
    static std::vector<uint8_t> digest(const std::string& data);

    // Returns the digest as a lowercase hex string (for debugging/tests).
    static std::string hexDigest(const std::string& data);

private:
    static uint32_t leftRotate(uint32_t value, uint32_t bits);
};

} // namespace sf

#endif // SMARTFINANCE_SHA1_H
