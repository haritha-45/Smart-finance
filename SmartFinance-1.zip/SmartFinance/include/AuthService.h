#ifndef SMARTFINANCE_AUTHSERVICE_H
#define SMARTFINANCE_AUTHSERVICE_H

#include <string>
#include <optional>
#include "MySqlManager.h"

namespace sf {

// AuthService
// Console-driven registration and login flows. Both require a
// TOTP one-time code in addition to the password (two-factor
// authentication), per the project requirement.
//
// NOTE ON "SENDING" THE OTP: a real deployment would email or SMS the
// code via a provider (SMTP, Twilio, etc.), which requires network
// access and account credentials this project does not have. Two
// delivery paths are supported here instead, and both use the exact
// same underlying RFC 6238 TOTP implementation a real deployment would:
//   1. Authenticator-app mode (recommended): the Base32 secret and an
//      otpauth:// URI are shown once at registration, exactly like a
//      real app's QR-code setup screen. The user adds it to Google
//      Authenticator / Authy / etc. and enters the 6-digit code it
//      shows.
//   2. Console-simulated delivery (for testing without an authenticator
///     app): the code is printed to the console labeled as a simulated
//      email, in the exact spot a real SMTP call would go (see
//      AuthService.cpp, function simulateSendOtp) -- swap that one
//      function for a real provider call to make delivery real.
class AuthService {
public:
    // Runs the interactive registration flow. Returns the created user
    // record on success, or std::nullopt if the user aborts or fails
    // OTP verification.
    static std::optional<UserRecord> registerFlow();

    // Runs the interactive login flow (password + TOTP). Returns the
    // authenticated user record on success, or std::nullopt otherwise.
    static std::optional<UserRecord> loginFlow();

    static bool isValidUsername(const std::string& username);
    static bool isValidEmail(const std::string& email);

private:
    static std::string promptLine(const std::string& prompt);
    static std::string promptPasswordMasked(const std::string& prompt);
    static bool runOtpChallenge(const std::string& totpSecret, const std::string& emailForDisplay);
    static void simulateSendOtp(const std::string& email, const std::string& code);
};

} // namespace sf

#endif // SMARTFINANCE_AUTHSERVICE_H
