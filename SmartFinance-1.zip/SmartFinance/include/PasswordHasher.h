#ifndef SMARTFINANCE_PASSWORDHASHER_H
#define SMARTFINANCE_PASSWORDHASHER_H

#include <string>

namespace sf {

// PasswordHasher
// Salted SHA-256 password hashing.
//
// NOTE: SHA-256 is a fast general-purpose hash, not a password KDF. A
// production system should use bcrypt, scrypt, or Argon2 (all
// deliberately slow, to resist brute-force/GPU attacks) instead of a
// bare hash -- this mirrors the caution already noted for User.cpp's
// original std::hash-based placeholder (Section 8.3, Security, in the
// design document). Salting at least prevents identical passwords from
// producing identical stored hashes across accounts.
class PasswordHasher {
public:
    // Generates a random hex-encoded salt.
    static std::string generateSalt(size_t byteLength = 16);

    // Returns hex(SHA256(salt + password)).
    static std::string hash(const std::string& password, const std::string& salt);

    // Convenience check.
    static bool verify(const std::string& password, const std::string& salt, const std::string& expectedHash);
};

} // namespace sf

#endif // SMARTFINANCE_PASSWORDHASHER_H
