#ifndef SMARTFINANCE_HMAC_H
#define SMARTFINANCE_HMAC_H

#include <string>
#include <vector>
#include <cstdint>

namespace sf {

// HMAC-SHA1 (RFC 2104), the hash construction required by RFC 6238 (TOTP)
// and RFC 4226 (HOTP).
class Hmac {
public:
    static std::vector<uint8_t> sha1(const std::vector<uint8_t>& key,
                                       const std::vector<uint8_t>& message);
};

} // namespace sf

#endif // SMARTFINANCE_HMAC_H
