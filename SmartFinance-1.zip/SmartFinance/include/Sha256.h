#ifndef SMARTFINANCE_SHA256_H
#define SMARTFINANCE_SHA256_H

#include <string>
#include <vector>
#include <cstdint>

namespace sf {

// Minimal, dependency-free SHA-256 implementation (FIPS 180-4).
// Used for salted password hashing (see PasswordHasher.h). SHA-256 alone
// is not a substitute for a proper password KDF (bcrypt/scrypt/Argon2) in
// a production system -- see the note in PasswordHasher.h.
class Sha256 {
public:
    static std::vector<uint8_t> digest(const std::vector<uint8_t>& data);
    static std::vector<uint8_t> digest(const std::string& data);
    static std::string hexDigest(const std::string& data);
};

} // namespace sf

#endif // SMARTFINANCE_SHA256_H
