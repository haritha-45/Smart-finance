#ifndef SMARTFINANCE_BASE32_H
#define SMARTFINANCE_BASE32_H

#include <string>
#include <vector>
#include <cstdint>

namespace sf {

// Base32 encoding/decoding (RFC 4648), used to represent TOTP secrets in
// the alphanumeric form that authenticator apps (Google Authenticator,
// Authy, etc.) expect users to type or scan.
class Base32 {
public:
    static std::string encode(const std::vector<uint8_t>& data);
    static std::vector<uint8_t> decode(const std::string& base32Text);
};

} // namespace sf

#endif // SMARTFINANCE_BASE32_H
