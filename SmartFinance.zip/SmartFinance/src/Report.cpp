#include "Report.h"
#include "DatabaseManager.h"
#include "Logger.h"
#include <sstream>
#include <iomanip>

namespace sf {

Report::Report(int reportId, ReportType type, std::string periodLabel)
    : reportId_(reportId), type_(type), periodLabel_(std::move(periodLabel)) {}

std::string Report::typeLabel(ReportType type) {
    switch (type) {
        case ReportType::DAILY: return "Daily Report";
        case ReportType::WEEKLY: return "Weekly Report";
        case ReportType::BEGINNING_OF_MONTH: return "Beginning-of-Month Report";
        case ReportType::MONTH_END: return "Month-End Report";
    }
    return "Report";
}

std::string Report::render(const std::vector<TransactionPtr>& transactions, const Budget& budget) const {
    std::ostringstream oss;
    oss << "===== " << typeLabel(type_) << " (" << periodLabel_ << ") =====\n";

    double totalIncome = 0.0, totalExpense = 0.0;
    for (const auto& t : transactions) {
        if (t->type() == "Income") totalIncome += t->amount();
        else totalExpense += t->amount();
    }
    oss << std::fixed << std::setprecision(2);
    oss << "Total Income:  Rs " << totalIncome << "\n";
    oss << "Total Expense: Rs " << totalExpense << "\n";
    oss << "Net:           Rs " << (totalIncome - totalExpense) << "\n\n";

    oss << "Category breakdown (spent / limit):\n";
    for (const auto& [category, limit] : budget.limits()) {
        oss << "  - " << category << ": Rs " << budget.getSpent(category)
            << " / Rs " << limit;
        if (budget.isExceeded(category)) oss << "  [EXCEEDED]";
        else if (budget.isApproachingLimit(category)) oss << "  [WARNING]";
        oss << "\n";
    }
    oss << "=====================================\n";
    return oss.str();
}

void Report::save(const std::string& renderedText) const {
    DatabaseManager::instance().insertRow("reports", {
        std::to_string(reportId_), typeLabel(type_), periodLabel_, renderedText
    });
    Logger::instance().info("Report", typeLabel(type_) + "_GENERATED",
        typeLabel(type_) + " generated for " + periodLabel_);
}

} // namespace sf
