#include "AlertManager.h"
#include "Logger.h"
#include <iostream>

namespace sf {

std::vector<Alert> AlertManager::evaluateBudget(const Budget& budget) {
    std::vector<Alert> alerts;
    for (const auto& [category, limit] : budget.limits()) {
        if (budget.isExceeded(category)) {
            double overage = budget.getSpent(category) - limit;
            alerts.push_back({AlertSeverity::CRITICAL,
                "Budget exceeded: '" + category + "' is over its limit by Rs " + money(overage)});
        } else if (budget.isApproachingLimit(category)) {
            alerts.push_back({AlertSeverity::WARNING,
                "Budget warning: '" + category + "' has used 90% or more of its limit"});
        }
    }
    double totalSpentRatio = budget.totalLimit() > 0.0 ? budget.totalSpent() / budget.totalLimit() : 0.0;
    if (totalSpentRatio > 1.10) {
        alerts.push_back({AlertSeverity::CRITICAL, "High spending: overall spend is more than 10% above plan"});
    }
    return alerts;
}

Alert AlertManager::checkSavingsProgress(double currentAmount, double targetAmount, double monthProgressPct) {
    if (targetAmount <= 0.0) {
        return {AlertSeverity::INFO, "No savings target set for this month."};
    }
    double expectedByNow = targetAmount * monthProgressPct;
    if (currentAmount < expectedByNow * 0.8) {
        return {AlertSeverity::WARNING, "Low savings: progress is behind pace for this month's target."};
    }
    return {AlertSeverity::INFO, "Savings progress is on track."};
}

void AlertManager::deliver(const Alert& alert) {
    std::string sev = alert.severity == AlertSeverity::CRITICAL ? "CRITICAL" :
                       alert.severity == AlertSeverity::WARNING ? "WARNING" : "INFO";
    std::cout << "[ALERT - " << sev << "] " << alert.message << std::endl;

    if (alert.severity == AlertSeverity::CRITICAL) {
        Logger::instance().warn("AlertManager", "LIMIT_EXCEEDED", alert.message);
    } else if (alert.severity == AlertSeverity::WARNING) {
        Logger::instance().warn("AlertManager", "LIMIT_APPROACHING", alert.message);
    } else {
        Logger::instance().info("AlertManager", "NOTICE", alert.message);
    }
}

} // namespace sf
