// main.cpp
// Demonstrates the full monthly cycle described in the design document's
// sequence diagrams (Section 14): beginning-of-month planning, expense
// entry with budget/alert checks, additional-income allocation, an
// emergency-expense flow, and month-end processing that isolates the
// surplus into the emergency reserve.

#include <iostream>
#include <iomanip>
#include <memory>
#include <vector>

#include "Logger.h"
#include "DatabaseManager.h"
#include "User.h"
#include "Transaction.h"
#include "Income.h"
#include "Expense.h"
#include "Budget.h"
#include "MonthlyPlan.h"
#include "Report.h"
#include "RecommendationEngine.h"
#include "AlertManager.h"
#include "SavingsManager.h"
#include "InvestmentAnalyzer.h"
#include "EmergencyFundManager.h"

using namespace sf;

static void printAllocation(const std::map<std::string, double>& allocation) {
    for (const auto& [bucket, amount] : allocation) {
        std::cout << "    - " << bucket << ": Rs " << amount << "\n";
    }
}

int main() {
    std::cout << std::fixed << std::setprecision(2);
    Logger::instance().info("System", "APP_START", "Application started.");

    // ---------------------------------------------------------------
    // 1. User setup / login
    // ---------------------------------------------------------------
    User user(1, "Asha Rao", "asha@example.com", "correct-horse-battery-staple");
    user.save();
    if (!user.login("correct-horse-battery-staple")) {
        std::cerr << "Login failed.\n";
        return 1;
    }
    std::cout << "Logged in as " << user.name() << "\n\n";

    // ---------------------------------------------------------------
    // 2. Use Case 1: Beginning-of-Month Planning
    // ---------------------------------------------------------------
    std::cout << "=== Beginning-of-Month Planning (September) ===\n";
    double salary = 50000.0;
    double fixedExpenses = 15000.0;
    double prevSurplus = 8000.0; // carried separately -- see EmergencyFundManager below
    EmergencyFundManager emergencyFund(prevSurplus);

    MonthlyPlan septemberPlan(1, "2026-09", salary, fixedExpenses, prevSurplus);
    auto categoryWeights = RecommendationEngine::recommendCategoryWeights(nullptr);
    double savingsTarget = 5000.0;
    Budget septemberBudget = septemberPlan.generatePlan(categoryWeights, savingsTarget);
    septemberPlan.save();
    septemberBudget.save();

    Report beginningReport(1, ReportType::BEGINNING_OF_MONTH, "2026-09");
    std::vector<TransactionPtr> septemberTransactions;
    std::string report1 = beginningReport.render(septemberTransactions, septemberBudget);
    beginningReport.save(report1);
    std::cout << report1 << "\n";

    // ---------------------------------------------------------------
    // 3. Use Case 2: Add Expense (+ budget/alert check)
    // ---------------------------------------------------------------
    std::cout << "=== Recording Expenses ===\n";
    auto groceries = std::make_shared<Expense>(101, "2026-09-05", 3200.0, "Weekly groceries", "Groceries", "UPI");
    if (groceries->validate()) {
        septemberBudget.recordSpend(*groceries);
        septemberTransactions.push_back(groceries);
    }

    auto dining = std::make_shared<Expense>(102, "2026-09-15", 4800.0, "Dinner out", "Dining", "Card");
    if (dining->validate()) {
        septemberBudget.recordSpend(*dining);
        septemberTransactions.push_back(dining);
    }
    for (const auto& alert : AlertManager::evaluateBudget(septemberBudget)) {
        AlertManager::deliver(alert);
    }
    std::cout << "\n";

    // ---------------------------------------------------------------
    // 4. Use Case 3: Add Additional Income -> allocation recommendation
    // ---------------------------------------------------------------
    std::cout << "=== Recording Additional Income ===\n";
    auto bonus = std::make_shared<Income>(103, "2026-09-15", 8000.0, "Festival bonus", "Employer", true);
    septemberTransactions.push_back(bonus);
    std::cout << "Recommended allocation for Rs " << bonus->amount() << " additional income:\n";
    auto allocation = RecommendationEngine::recommendAllocation(bonus->amount());
    printAllocation(allocation);
    // In a real UI, the user reviews/edits `allocation` here before it is
    // committed (BR-018). We commit it as-is for this demonstration.
    emergencyFund.addSurplus(allocation["EmergencyFund"]);
    std::cout << "\n";

    // ---------------------------------------------------------------
    // 5. Use Case 5: Emergency Expense
    // ---------------------------------------------------------------
    std::cout << "=== Emergency Expense Scenario ===\n";
    double emergencyCost = 6000.0;
    double availableThisMonth = septemberBudget.getRemaining("Miscellaneous");
    double shortfall = emergencyCost - availableThisMonth;
    if (shortfall > 0.0 && emergencyFund.isEligibleForUse(shortfall)) {
        std::cout << "Shortfall of Rs " << shortfall << " detected. Reserve is eligible.\n";
        std::cout << "Recommending reserve use to the user for approval...\n";
        bool userApproved = true; // simulated user approval
        if (userApproved && emergencyFund.withdraw(shortfall)) {
            std::cout << "Reserve withdrawal approved and completed. Remaining reserve: Rs "
                      << emergencyFund.reserveAmount() << "\n";
        }
    } else {
        std::cout << "No emergency reserve action required.\n";
    }
    std::cout << "\n";

    // ---------------------------------------------------------------
    // 6. Investment suggestion (informational only)
    // ---------------------------------------------------------------
    std::cout << "=== Investment Suggestion ===\n";
    std::cout << InvestmentAnalyzer::suggest(RiskLevel::MEDIUM, allocation["Investments"]) << "\n\n";

    // ---------------------------------------------------------------
    // 7. Use Case 6: Month-End Processing
    // ---------------------------------------------------------------
    std::cout << "=== Month-End Processing ===\n";
    Report monthEndReport(2, ReportType::MONTH_END, "2026-09");
    std::string report2 = monthEndReport.render(septemberTransactions, septemberBudget);
    monthEndReport.save(report2);
    std::cout << report2 << "\n";

    double monthEndSurplus = septemberBudget.totalLimit() - septemberBudget.totalSpent();
    if (monthEndSurplus > 0.0) {
        // Rule: remaining funds become a SEPARATE reserve, never part of
        // next month's normal spending budget (design document, Section 1).
        emergencyFund.addSurplus(monthEndSurplus);
    }
    emergencyFund.save();
    std::cout << "October's budget will be planned from Rs " << salary
              << " salary only; Rs " << emergencyFund.reserveAmount()
              << " remains isolated in the emergency reserve.\n";

    Logger::instance().info("System", "APP_END", "Application completed successfully.");
    return 0;
}
