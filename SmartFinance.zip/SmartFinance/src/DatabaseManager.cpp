#include "DatabaseManager.h"
#include "Logger.h"
#include <fstream>
#include <sstream>

namespace sf {

namespace {
    const char FIELD_SEP = '\x1F'; // ASCII Unit Separator - safe against commas/pipes in free text
    const char ROW_ESCAPED_SEP[] = "\\u001F";
}

DatabaseManager::DatabaseManager() : dbPath_("database/smartfinance.db") {}

DatabaseManager& DatabaseManager::instance() {
    static DatabaseManager mgr;
    return mgr;
}

void DatabaseManager::setDatabasePath(const std::string& path) {
    dbPath_ = path;
}

std::string DatabaseManager::escape(const std::string& field) {
    std::string result;
    result.reserve(field.size());
    for (char c : field) {
        if (c == FIELD_SEP || c == '\n') {
            result += ROW_ESCAPED_SEP;
        } else {
            result += c;
        }
    }
    return result;
}

std::string DatabaseManager::unescape(const std::string& field) {
    // Escaping only strips characters that would otherwise corrupt row
    // structure; plain reads do not need to reverse it for this reference
    // implementation, so the field is returned unchanged.
    return field;
}

bool DatabaseManager::insertRow(const std::string& table, const Row& fields) {
    std::ofstream out(dbPath_, std::ios::app);
    if (!out.is_open()) {
        Logger::instance().error("DatabaseManager", "DB_ERROR",
                                   "Unable to open database file for write: " + dbPath_);
        return false;
    }
    out << table;
    for (const auto& f : fields) {
        out << FIELD_SEP << escape(f);
    }
    out << "\n";
    return true;
}

std::vector<DatabaseManager::Row> DatabaseManager::queryTable(const std::string& table) {
    std::vector<Row> results;
    std::ifstream in(dbPath_);
    if (!in.is_open()) {
        // No records persisted yet is not an error condition.
        return results;
    }
    std::string line;
    while (std::getline(in, line)) {
        if (line.empty()) continue;
        std::vector<std::string> parts;
        std::string current;
        for (char c : line) {
            if (c == FIELD_SEP) {
                parts.push_back(current);
                current.clear();
            } else {
                current += c;
            }
        }
        parts.push_back(current);
        if (!parts.empty() && parts[0] == table) {
            Row row(parts.begin() + 1, parts.end());
            results.push_back(row);
        }
    }
    return results;
}

bool DatabaseManager::deleteTable(const std::string& table) {
    std::ifstream in(dbPath_);
    if (!in.is_open()) return true; // nothing to delete
    std::vector<std::string> keptLines;
    std::string line;
    while (std::getline(in, line)) {
        if (line.rfind(table + std::string(1, FIELD_SEP), 0) != 0) {
            keptLines.push_back(line);
        }
    }
    in.close();
    std::ofstream out(dbPath_, std::ios::trunc);
    if (!out.is_open()) {
        Logger::instance().error("DatabaseManager", "DB_ERROR",
                                   "Unable to open database file for rewrite: " + dbPath_);
        return false;
    }
    for (const auto& l : keptLines) out << l << "\n";
    return true;
}

} // namespace sf
