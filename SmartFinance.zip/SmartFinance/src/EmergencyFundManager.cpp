#include "EmergencyFundManager.h"
#include "DatabaseManager.h"
#include "Logger.h"

namespace sf {

EmergencyFundManager::EmergencyFundManager(double initialReserve) : reserveAmount_(initialReserve) {}

void EmergencyFundManager::addSurplus(double surplus) {
    if (surplus <= 0.0) return;
    reserveAmount_ += surplus;
    Logger::instance().info("EmergencyFundManager", "SURPLUS_TRANSFERRED",
        "Rs " + money(surplus) + " moved to emergency reserve; reserve now Rs " +
        money(reserveAmount_));
}

bool EmergencyFundManager::isEligibleForUse(double shortfallAmount) const {
    return shortfallAmount > 0.0 && reserveAmount_ >= shortfallAmount;
}

bool EmergencyFundManager::withdraw(double amount) {
    if (amount <= 0.0 || amount > reserveAmount_) {
        Logger::instance().warn("EmergencyFundManager", "WITHDRAWAL_REJECTED",
            "Requested withdrawal of Rs " + money(amount) + " exceeds available reserve");
        return false;
    }
    reserveAmount_ -= amount;
    Logger::instance().warn("EmergencyFundManager", "RESERVE_ACCESSED",
        "Rs " + money(amount) + " withdrawn from emergency reserve after user approval");
    return true;
}

void EmergencyFundManager::save() const {
    DatabaseManager::instance().insertRow("emergency_fund", { money(reserveAmount_) });
}

} // namespace sf
