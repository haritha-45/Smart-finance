#include "Income.h"

namespace sf {

Income::Income(int transactionId, std::string date, double amount, std::string description,
               std::string source, bool isAdditional)
    : Transaction(transactionId, std::move(date), amount, std::move(description)),
      source_(std::move(source)), isAdditional_(isAdditional) {}

IncomeType Income::classify() const {
    return isAdditional_ ? IncomeType::ADDITIONAL : IncomeType::SALARY;
}

std::vector<std::string> Income::toRow() const {
    auto row = Transaction::toRow();
    row.push_back(source_);
    row.push_back(isAdditional_ ? "1" : "0");
    return row;
}

} // namespace sf
