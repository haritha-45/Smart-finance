#include "Transaction.h"

namespace sf {

Transaction::Transaction(int transactionId, std::string date, double amount, std::string description)
    : transactionId_(transactionId), date_(std::move(date)), amount_(amount),
      description_(std::move(description)) {}

bool Transaction::validate() const {
    return amount_ > 0.0 && !date_.empty();
}

std::vector<std::string> Transaction::toRow() const {
    return { std::to_string(transactionId_), date_, std::to_string(amount_), description_, type() };
}

} // namespace sf
