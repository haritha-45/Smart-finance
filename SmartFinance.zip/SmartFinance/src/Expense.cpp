#include "Expense.h"
#include "Logger.h"

namespace sf {

Expense::Expense(int transactionId, std::string date, double amount, std::string description,
                  std::string category, std::string paymentMethod)
    : Transaction(transactionId, std::move(date), amount, std::move(description)),
      category_(std::move(category)), paymentMethod_(std::move(paymentMethod)) {}

void Expense::categorize(const std::string& category) {
    category_ = category;
    Logger::instance().info("Expense", "RECATEGORIZED",
                              "Expense " + std::to_string(transactionId_) + " moved to category " + category);
}

std::vector<std::string> Expense::toRow() const {
    auto row = Transaction::toRow();
    row.push_back(category_);
    row.push_back(paymentMethod_);
    return row;
}

} // namespace sf
