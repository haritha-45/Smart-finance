#include "RecommendationEngine.h"
#include "Logger.h"

namespace sf {

std::map<std::string, double> RecommendationEngine::recommendAllocation(double additionalIncome) {
    // Proposed default split; the user may approve or modify it (BR-018).
    std::map<std::string, double> allocation;
    allocation["Savings"]        = additionalIncome * 0.30;
    allocation["EmergencyFund"]  = additionalIncome * 0.20;
    allocation["Investments"]    = additionalIncome * 0.20;
    allocation["FinancialGoals"] = additionalIncome * 0.15;
    allocation["FlexibleSpending"] = additionalIncome * 0.15;

    Logger::instance().info("RecommendationEngine", "ALLOCATION_RECOMMENDED",
        "Additional income allocation recommended for Rs " + money(additionalIncome));
    return allocation;
}

std::vector<Recommendation> RecommendationEngine::recommendSavingReductions(const Budget& budget) {
    std::vector<Recommendation> recs;
    for (const auto& [category, limit] : budget.limits()) {
        double spent = budget.getSpent(category);
        if (limit > 0.0 && spent > limit * 0.9) {
            double overage = spent - limit;
            Recommendation r;
            r.type = "SAVING_REDUCTION";
            r.amount = overage > 0 ? overage : limit * 0.1;
            r.suggestedAction = "Consider reducing '" + category + "' spending by approximately Rs " +
                                  money(r.amount) + " next month.";
            recs.push_back(r);
        }
    }
    Logger::instance().info("RecommendationEngine", "SAVING_RECOMMENDATION",
        "Saving recommendation generated (" + std::to_string(recs.size()) + " categories flagged)");
    return recs;
}

std::map<std::string, double> RecommendationEngine::recommendCategoryWeights(const Budget* previousMonthBudget) {
    if (previousMonthBudget != nullptr && previousMonthBudget->totalSpent() > 0.0) {
        std::map<std::string, double> weights;
        double total = previousMonthBudget->totalSpent();
        for (const auto& [category, spent] : previousMonthBudget->spent()) {
            weights[category] = spent / total;
        }
        return weights;
    }
    // Default starter weights when no history is available yet.
    return {
        {"Groceries", 0.25}, {"Utilities", 0.15}, {"Transport", 0.15},
        {"Dining", 0.15}, {"Entertainment", 0.10}, {"Miscellaneous", 0.20}
    };
}

} // namespace sf
