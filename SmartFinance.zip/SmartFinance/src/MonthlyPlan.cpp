#include "MonthlyPlan.h"
#include "DatabaseManager.h"
#include "Logger.h"

namespace sf {

MonthlyPlan::MonthlyPlan(int planId, std::string month, double salary, double fixedExpenses, double prevSurplus)
    : planId_(planId), month_(std::move(month)), salary_(salary),
      fixedExpenses_(fixedExpenses), prevSurplus_(prevSurplus) {}

double MonthlyPlan::availableForBudgeting() const {
    // Deliberately excludes prevSurplus_: previous-month surplus must never
    // automatically inflate the current month's normal spending budget
    // (design document, Section 1, "Important Financial Rule").
    return salary_ - fixedExpenses_;
}

Budget MonthlyPlan::generatePlan(const std::map<std::string, double>& categoryWeights, double savingsTarget) {
    Budget budget(planId_, month_);
    double discretionary = availableForBudgeting() - savingsTarget;
    if (discretionary < 0.0) {
        Logger::instance().warn("MonthlyPlan", "PLAN_TIGHT",
            "Savings target exceeds available funds for " + month_);
        discretionary = 0.0;
    }
    for (const auto& [category, weight] : categoryWeights) {
        budget.setCategoryLimit(category, discretionary * weight);
    }
    Logger::instance().info("MonthlyPlan", "BUDGET_GENERATED",
        "Monthly plan generated for " + month_ + " with " + std::to_string(categoryWeights.size()) + " categories");
    return budget;
}

void MonthlyPlan::save() const {
    DatabaseManager::instance().insertRow("monthly_plans", {
        std::to_string(planId_), month_, std::to_string(salary_),
        std::to_string(fixedExpenses_), std::to_string(prevSurplus_)
    });
}

} // namespace sf
