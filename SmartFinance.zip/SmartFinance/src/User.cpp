#include "User.h"
#include "DatabaseManager.h"
#include "Logger.h"
#include <functional>
#include <sstream>

namespace sf {

User::User(int userId, std::string name, std::string email, const std::string& password)
    : userId_(userId), name_(std::move(name)), email_(std::move(email)),
      passwordHash_(hashPassword(password)) {}

std::string User::hashPassword(const std::string& password) {
    // NOTE: std::hash is used here only to keep this reference
    // implementation dependency-free. A production build should replace
    // this with a vetted algorithm (e.g., bcrypt/Argon2) as called out in
    // the Non-Functional Requirements (Section 8.3, Security).
    std::hash<std::string> hasher;
    std::ostringstream oss;
    oss << hasher(password);
    return oss.str();
}

bool User::login(const std::string& password) const {
    bool ok = hashPassword(password) == passwordHash_;
    if (ok) {
        Logger::instance().info("User", "LOGIN_SUCCESS", "User login successful for " + email_);
    } else {
        Logger::instance().warn("User", "LOGIN_FAILED", "Failed login attempt for " + email_);
    }
    return ok;
}

void User::updateProfile(const std::string& name, const std::string& email) {
    name_ = name;
    email_ = email;
    Logger::instance().info("User", "PROFILE_UPDATED", "Profile updated for user id " + std::to_string(userId_));
}

void User::save() const {
    DatabaseManager::instance().insertRow("users", {
        std::to_string(userId_), name_, email_, passwordHash_
    });
}

} // namespace sf
