#include "Budget.h"
#include "DatabaseManager.h"
#include "Logger.h"

namespace sf {

Budget::Budget(int budgetId, std::string month) : budgetId_(budgetId), month_(std::move(month)) {}

void Budget::setCategoryLimit(const std::string& category, double limit) {
    categoryLimits_[category] = limit;
    if (categorySpent_.find(category) == categorySpent_.end()) {
        categorySpent_[category] = 0.0;
    }
}

double Budget::getLimit(const std::string& category) const {
    auto it = categoryLimits_.find(category);
    return it == categoryLimits_.end() ? 0.0 : it->second;
}

void Budget::recordSpend(const Expense& expense) {
    categorySpent_[expense.category()] += expense.amount();
    Logger::instance().info("Budget", "SPEND_RECORDED",
        "Category '" + expense.category() + "' spend now " +
        money(categorySpent_[expense.category()]));

    if (isExceeded(expense.category())) {
        Logger::instance().warn("Budget", "LIMIT_EXCEEDED",
            expense.category() + " budget exceeded by " +
            money(getSpent(expense.category()) - getLimit(expense.category())));
    } else if (isApproachingLimit(expense.category())) {
        Logger::instance().warn("Budget", "LIMIT_APPROACHING",
            expense.category() + " spend is approaching its limit");
    }
}

double Budget::getSpent(const std::string& category) const {
    auto it = categorySpent_.find(category);
    return it == categorySpent_.end() ? 0.0 : it->second;
}

double Budget::getRemaining(const std::string& category) const {
    return getLimit(category) - getSpent(category);
}

bool Budget::isExceeded(const std::string& category) const {
    return getSpent(category) > getLimit(category) && getLimit(category) > 0.0;
}

bool Budget::isApproachingLimit(const std::string& category, double warnThresholdPct) const {
    double limit = getLimit(category);
    if (limit <= 0.0) return false;
    return getSpent(category) >= limit * warnThresholdPct && !isExceeded(category);
}

double Budget::totalLimit() const {
    double total = 0.0;
    for (const auto& [cat, limit] : categoryLimits_) total += limit;
    return total;
}

double Budget::totalSpent() const {
    double total = 0.0;
    for (const auto& [cat, spent] : categorySpent_) total += spent;
    return total;
}

void Budget::save() const {
    for (const auto& [category, limit] : categoryLimits_) {
        DatabaseManager::instance().insertRow("budgets", {
            std::to_string(budgetId_), month_, category,
            money(limit), money(getSpent(category))
        });
    }
}

} // namespace sf
