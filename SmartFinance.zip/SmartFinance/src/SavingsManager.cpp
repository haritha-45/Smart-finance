#include "SavingsManager.h"
#include "DatabaseManager.h"
#include "Logger.h"

namespace sf {

SavingsGoal::SavingsGoal(int goalId, std::string month, double targetAmount)
    : goalId_(goalId), month_(std::move(month)), targetAmount_(targetAmount) {}

void SavingsGoal::contribute(double amount) {
    currentAmount_ += amount;
    Logger::instance().info("SavingsManager", "CONTRIBUTION_RECORDED",
        "Savings goal " + std::to_string(goalId_) + " now at " + std::to_string(currentAmount_));
}

double SavingsGoal::progress() const {
    if (targetAmount_ <= 0.0) return 0.0;
    return currentAmount_ / targetAmount_;
}

void SavingsManager::save(const SavingsGoal& goal) {
    DatabaseManager::instance().insertRow("savings_goals", {
        std::to_string(goal.id()), std::to_string(goal.targetAmount()), std::to_string(goal.currentAmount())
    });
}

bool SavingsManager::isBehindPace(const SavingsGoal& goal, double monthProgressPct) {
    return goal.progress() < monthProgressPct * 0.8;
}

} // namespace sf
