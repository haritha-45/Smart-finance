#include "InvestmentAnalyzer.h"
#include "Logger.h"

namespace sf {

Investment::Investment(int investmentId, RiskLevel risk, double allocatedAmount)
    : investmentId_(investmentId), risk_(risk), allocatedAmount_(allocatedAmount) {}

double Investment::estimateROI() const {
    // Illustrative, informational bands only -- see System Limitations
    // (Section 4): investment suggestions cannot guarantee returns.
    switch (risk_) {
        case RiskLevel::LOW:    return allocatedAmount_ * 0.05;
        case RiskLevel::MEDIUM: return allocatedAmount_ * 0.09;
        case RiskLevel::HIGH:   return allocatedAmount_ * 0.14;
    }
    return 0.0;
}

std::string InvestmentAnalyzer::riskLevelToString(RiskLevel risk) {
    switch (risk) {
        case RiskLevel::LOW: return "Low";
        case RiskLevel::MEDIUM: return "Medium";
        case RiskLevel::HIGH: return "High";
    }
    return "Unknown";
}

std::string InvestmentAnalyzer::suggest(RiskLevel risk, double availableSurplus) {
    Logger::instance().info("InvestmentAnalyzer", "SUGGESTION_GENERATED",
        "Investment suggestion generated for risk=" + riskLevelToString(risk));

    if (availableSurplus <= 0.0) {
        return "No surplus currently available for investment consideration.";
    }
    switch (risk) {
        case RiskLevel::LOW:
            return "Consider low-risk instruments such as fixed deposits or debt funds for Rs " +
                   money(availableSurplus) + " (educational suggestion only).";
        case RiskLevel::MEDIUM:
            return "Consider a balanced mix of index funds and debt instruments for Rs " +
                   money(availableSurplus) + " (educational suggestion only).";
        case RiskLevel::HIGH:
            return "Consider equity-oriented mutual funds for Rs " +
                   money(availableSurplus) + ", consistent with a high risk tolerance " +
                   "(educational suggestion only, not a guarantee of returns).";
    }
    return "";
}

} // namespace sf
