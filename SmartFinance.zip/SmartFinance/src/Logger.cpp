#include "Logger.h"
#include <iostream>
#include <ctime>
#include <iomanip>
#include <sstream>

namespace sf {

std::string money(double amount) {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(2) << amount;
    return oss.str();
}

Logger::Logger() {
    out_.open("logs/application.log", std::ios::app);
    if (!out_.is_open()) {
        // Fall back silently; console output will still occur via std::cerr.
        std::cerr << "[Logger] Warning: could not open logs/application.log\n";
    }
}

Logger::~Logger() {
    if (out_.is_open()) out_.close();
}

Logger& Logger::instance() {
    static Logger instance;
    return instance;
}

void Logger::setLogFile(const std::string& path) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (out_.is_open()) out_.close();
    out_.open(path, std::ios::app);
}

std::string Logger::levelToString(LogLevel level) {
    switch (level) {
        case LogLevel::DEBUG: return "DEBUG";
        case LogLevel::INFO:  return "INFO";
        case LogLevel::WARN:  return "WARN";
        case LogLevel::ERR:   return "ERROR";
    }
    return "UNKNOWN";
}

std::string Logger::currentTimestamp() {
    std::time_t t = std::time(nullptr);
    std::tm tmBuf{};
#if defined(_WIN32)
    localtime_s(&tmBuf, &t);
#else
    localtime_r(&t, &tmBuf);
#endif
    std::ostringstream oss;
    oss << std::put_time(&tmBuf, "%Y-%m-%d %H:%M:%S");
    return oss.str();
}

void Logger::log(LogLevel level, const std::string& module,
                   const std::string& event, const std::string& description) {
    std::lock_guard<std::mutex> lock(mutex_);
    std::ostringstream line;
    line << currentTimestamp() << " | " << levelToString(level) << " | "
         << module << " | " << event << " | " << description;

    if (out_.is_open()) {
        out_ << line.str() << std::endl;
    }
    // Mirror WARN/ERROR to console so CLI usage surfaces problems immediately.
    if (level == LogLevel::WARN || level == LogLevel::ERR) {
        std::cerr << line.str() << std::endl;
    }
}

void Logger::info(const std::string& module, const std::string& event, const std::string& description) {
    log(LogLevel::INFO, module, event, description);
}
void Logger::warn(const std::string& module, const std::string& event, const std::string& description) {
    log(LogLevel::WARN, module, event, description);
}
void Logger::error(const std::string& module, const std::string& event, const std::string& description) {
    log(LogLevel::ERR, module, event, description);
}
void Logger::debug(const std::string& module, const std::string& event, const std::string& description) {
    log(LogLevel::DEBUG, module, event, description);
}

} // namespace sf
