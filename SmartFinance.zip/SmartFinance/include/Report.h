#ifndef SMARTFINANCE_REPORT_H
#define SMARTFINANCE_REPORT_H

#include <string>
#include <vector>
#include "Transaction.h"
#include "Budget.h"

namespace sf {

enum class ReportType { DAILY, WEEKLY, BEGINNING_OF_MONTH, MONTH_END };

// Report
// Produces daily, weekly, beginning-of-month, and month-end reports.
// A single class parameterized by ReportType is used instead of three
// separate subclasses (DailyReport/WeeklyReport/MonthlyReport) to keep
// the module count aligned with the project's directory structure; the
// UML class diagram in the design document shows the equivalent
// specialization relationship.
class Report {
public:
    Report(int reportId, ReportType type, std::string periodLabel);

    int id() const { return reportId_; }
    ReportType type() const { return type_; }

    // Builds the textual report body from the given transactions and budget.
    std::string render(const std::vector<TransactionPtr>& transactions, const Budget& budget) const;

    void save(const std::string& renderedText) const;

private:
    int reportId_;
    ReportType type_;
    std::string periodLabel_;

    static std::string typeLabel(ReportType type);
};

} // namespace sf

#endif // SMARTFINANCE_REPORT_H
