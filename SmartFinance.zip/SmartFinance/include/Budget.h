#ifndef SMARTFINANCE_BUDGET_H
#define SMARTFINANCE_BUDGET_H

#include <string>
#include <map>
#include <vector>
#include "Expense.h"

namespace sf {

// Budget
// Holds the category-wise spending limits for a single month, and tracks
// actual spend against those limits as expenses are recorded.
class Budget {
public:
    Budget(int budgetId, std::string month);

    int id() const { return budgetId_; }
    const std::string& month() const { return month_; }

    void setCategoryLimit(const std::string& category, double limit);
    double getLimit(const std::string& category) const;

    // Applies an expense's amount against its category's running total.
    void recordSpend(const Expense& expense);

    double getSpent(const std::string& category) const;
    double getRemaining(const std::string& category) const;
    bool isExceeded(const std::string& category) const;
    bool isApproachingLimit(const std::string& category, double warnThresholdPct = 0.9) const;

    // Total planned budget across all categories.
    double totalLimit() const;
    double totalSpent() const;

    const std::map<std::string, double>& limits() const { return categoryLimits_; }
    const std::map<std::string, double>& spent() const { return categorySpent_; }

    void save() const;

private:
    int budgetId_;
    std::string month_; // e.g. "2026-09"
    std::map<std::string, double> categoryLimits_;
    std::map<std::string, double> categorySpent_;
};

} // namespace sf

#endif // SMARTFINANCE_BUDGET_H
