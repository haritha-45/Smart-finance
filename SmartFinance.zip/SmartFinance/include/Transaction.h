#ifndef SMARTFINANCE_TRANSACTION_H
#define SMARTFINANCE_TRANSACTION_H

#include <string>
#include <memory>
#include <vector>

namespace sf {

// Transaction
// Base class for a single recorded financial event. Income and Expense
// specialize this class (see Income.h / Expense.h).
class Transaction {
public:
    Transaction(int transactionId, std::string date, double amount, std::string description);
    virtual ~Transaction() = default;

    int id() const { return transactionId_; }
    const std::string& date() const { return date_; }
    double amount() const { return amount_; }
    const std::string& description() const { return description_; }

    // Basic sanity check applied before persistence.
    virtual bool validate() const;

    // Human-readable type label, overridden by Income/Expense.
    virtual std::string type() const = 0;

    // Serializes to a row suitable for DatabaseManager::insertRow.
    virtual std::vector<std::string> toRow() const;

protected:
    int transactionId_;
    std::string date_;        // ISO 8601, e.g. "2026-09-15"
    double amount_;
    std::string description_;
};

using TransactionPtr = std::shared_ptr<Transaction>;

} // namespace sf

#endif // SMARTFINANCE_TRANSACTION_H
