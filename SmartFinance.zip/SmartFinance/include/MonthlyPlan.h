#ifndef SMARTFINANCE_MONTHLYPLAN_H
#define SMARTFINANCE_MONTHLYPLAN_H

#include <string>
#include <map>
#include "Budget.h"

namespace sf {

// MonthlyPlan
// Represents the beginning-of-month financial plan: salary, known fixed
// expenses, the previous month's surplus (tracked but never merged into
// the current month's normal spending budget), and the resulting
// category-wise budget allocation.
class MonthlyPlan {
public:
    MonthlyPlan(int planId, std::string month, double salary, double fixedExpenses, double prevSurplus);

    int id() const { return planId_; }
    double salary() const { return salary_; }
    double fixedExpenses() const { return fixedExpenses_; }
    double prevSurplus() const { return prevSurplus_; }
    double availableForBudgeting() const; // salary - fixedExpenses (surplus intentionally excluded)

    // Distributes availableForBudgeting() across the given categories
    // using the supplied weights (must sum to 1.0) and produces a Budget.
    Budget generatePlan(const std::map<std::string, double>& categoryWeights, double savingsTarget);

    void save() const;

private:
    int planId_;
    std::string month_;
    double salary_;
    double fixedExpenses_;
    double prevSurplus_;
};

} // namespace sf

#endif // SMARTFINANCE_MONTHLYPLAN_H
