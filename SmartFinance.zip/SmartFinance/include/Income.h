#ifndef SMARTFINANCE_INCOME_H
#define SMARTFINANCE_INCOME_H

#include "Transaction.h"

namespace sf {

enum class IncomeType { SALARY, ADDITIONAL };

// Income
// Specializes Transaction for money received. Additional income (received
// mid-month, outside the primary salary) is flagged via isAdditional() and
// is never merged into the original salary-based budget automatically
// (see Section 1, "Additional Income Rule", in the design document).
class Income : public Transaction {
public:
    Income(int transactionId, std::string date, double amount, std::string description,
           std::string source, bool isAdditional);

    std::string type() const override { return "Income"; }
    const std::string& source() const { return source_; }
    bool isAdditional() const { return isAdditional_; }
    IncomeType classify() const;

    std::vector<std::string> toRow() const override;

private:
    std::string source_;
    bool isAdditional_;
};

} // namespace sf

#endif // SMARTFINANCE_INCOME_H
