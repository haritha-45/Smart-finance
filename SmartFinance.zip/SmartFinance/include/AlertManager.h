#ifndef SMARTFINANCE_ALERTMANAGER_H
#define SMARTFINANCE_ALERTMANAGER_H

#include <string>
#include <vector>
#include "Budget.h"

namespace sf {

enum class AlertSeverity { INFO, WARNING, CRITICAL };

struct Alert {
    AlertSeverity severity;
    std::string message;
};

// AlertManager
// Evaluates budget thresholds and raises budget-warning, budget-exceeded,
// high-spending, and low-savings alerts. Also absorbs the lightweight
// "Notification Manager" role shown in the architecture diagram by
// providing deliver(), since the initial release has a single in-app
// notification channel.
class AlertManager {
public:
    // Scans every category in the budget and returns any alerts raised.
    static std::vector<Alert> evaluateBudget(const Budget& budget);

    // Raises a low-savings alert if progress is behind the target pace.
    static Alert checkSavingsProgress(double currentAmount, double targetAmount, double monthProgressPct);

    // Delivers (prints/logs) an alert to the user.
    static void deliver(const Alert& alert);
};

} // namespace sf

#endif // SMARTFINANCE_ALERTMANAGER_H
