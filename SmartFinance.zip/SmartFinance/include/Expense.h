#ifndef SMARTFINANCE_EXPENSE_H
#define SMARTFINANCE_EXPENSE_H

#include "Transaction.h"

namespace sf {

// Expense
// Specializes Transaction for money spent, assigned to a spending
// category and payment method.
class Expense : public Transaction {
public:
    Expense(int transactionId, std::string date, double amount, std::string description,
            std::string category, std::string paymentMethod);

    std::string type() const override { return "Expense"; }
    const std::string& category() const { return category_; }
    const std::string& paymentMethod() const { return paymentMethod_; }

    // Re-assigns the category (e.g., after manual correction).
    void categorize(const std::string& category);

    std::vector<std::string> toRow() const override;

private:
    std::string category_;
    std::string paymentMethod_;
};

} // namespace sf

#endif // SMARTFINANCE_EXPENSE_H
