#ifndef SMARTFINANCE_DATABASEMANAGER_H
#define SMARTFINANCE_DATABASEMANAGER_H

#include <string>
#include <vector>

namespace sf {

// DatabaseManager
// Single point of access to persistent storage, isolating every other
// module from the storage engine in use.
//
// NOTE ON STORAGE ENGINE:
// The design document specifies SQLite for the initial release. This
// reference implementation persists to a simple delimited flat file
// (database/smartfinance.db) instead, because the build environment used
// to produce this code does not have the libsqlite3 development headers
// available. The public interface below is intentionally storage-agnostic
// (table name + row of string fields) so the flat-file body of each method
// can be replaced with real `sqlite3_prepare_v2`/`sqlite3_step` calls
// without changing a single call site elsewhere in the project. To switch
// to real SQLite: add `#include <sqlite3.h>`, link with `-lsqlite3`, and
// reimplement insertRow/queryTable/deleteTable accordingly.
class DatabaseManager {
public:
    using Row = std::vector<std::string>;

    static DatabaseManager& instance();

    void setDatabasePath(const std::string& path);

    // Appends one row to the named table (table == a section of the file).
    bool insertRow(const std::string& table, const Row& fields);

    // Returns every row previously inserted under the named table.
    std::vector<Row> queryTable(const std::string& table);

    // Removes all rows for a table (used by tests / resets).
    bool deleteTable(const std::string& table);

private:
    DatabaseManager();
    DatabaseManager(const DatabaseManager&) = delete;
    DatabaseManager& operator=(const DatabaseManager&) = delete;

    std::string dbPath_;

    static std::string escape(const std::string& field);
    static std::string unescape(const std::string& field);
};

} // namespace sf

#endif // SMARTFINANCE_DATABASEMANAGER_H
