#ifndef SMARTFINANCE_SAVINGSMANAGER_H
#define SMARTFINANCE_SAVINGSMANAGER_H

#include <string>

namespace sf {

// SavingsGoal
// A single savings objective with a target amount and running progress.
class SavingsGoal {
public:
    SavingsGoal(int goalId, std::string month, double targetAmount);

    int id() const { return goalId_; }
    double targetAmount() const { return targetAmount_; }
    double currentAmount() const { return currentAmount_; }

    void contribute(double amount);
    double progress() const; // 0.0 - 1.0 (may exceed 1.0 if over target)

private:
    int goalId_;
    std::string month_;
    double targetAmount_;
    double currentAmount_ = 0.0;
};

// SavingsManager
// Tracks progress toward savings goals and computes achievable savings
// recommendations in cooperation with the RecommendationEngine.
class SavingsManager {
public:
    static void save(const SavingsGoal& goal);
    static bool isBehindPace(const SavingsGoal& goal, double monthProgressPct);
};

} // namespace sf

#endif // SMARTFINANCE_SAVINGSMANAGER_H
