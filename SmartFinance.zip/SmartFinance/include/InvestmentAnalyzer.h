#ifndef SMARTFINANCE_INVESTMENTANALYZER_H
#define SMARTFINANCE_INVESTMENTANALYZER_H

#include <string>
#include <vector>

namespace sf {

enum class RiskLevel { LOW, MEDIUM, HIGH };

// Investment
// An allocation of funds toward an investment instrument, tracked for
// informational purposes only. The system never executes trades (FR-094).
class Investment {
public:
    Investment(int investmentId, RiskLevel risk, double allocatedAmount);

    int id() const { return investmentId_; }
    RiskLevel risk() const { return risk_; }
    double allocatedAmount() const { return allocatedAmount_; }

    // Rough, informational ROI estimate based on risk band. Not a
    // guarantee (System Limitations, Section 4).
    double estimateROI() const;

private:
    int investmentId_;
    RiskLevel risk_;
    double allocatedAmount_;
};

// InvestmentAnalyzer
// Captures risk preference and produces educational investment
// suggestions, optionally informed by external market data.
class InvestmentAnalyzer {
public:
    // Suggests an instrument category given risk preference and available surplus.
    static std::string suggest(RiskLevel risk, double availableSurplus);

    static std::string riskLevelToString(RiskLevel risk);
};

} // namespace sf

#endif // SMARTFINANCE_INVESTMENTANALYZER_H
