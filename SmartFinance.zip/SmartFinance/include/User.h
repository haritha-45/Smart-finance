#ifndef SMARTFINANCE_USER_H
#define SMARTFINANCE_USER_H

#include <string>

namespace sf {

// User
// Represents the account owner. Also absorbs the lightweight
// authentication responsibilities shown as "Authentication Manager" in
// the architecture diagram, since the initial release is single-user.
class User {
public:
    User(int userId, std::string name, std::string email, const std::string& password);

    int id() const { return userId_; }
    const std::string& name() const { return name_; }
    const std::string& email() const { return email_; }

    // Verifies a plaintext password against the stored hash.
    bool login(const std::string& password) const;

    void updateProfile(const std::string& name, const std::string& email);

    // Persists the user record via DatabaseManager.
    void save() const;

private:
    int userId_;
    std::string name_;
    std::string email_;
    std::string passwordHash_;

    static std::string hashPassword(const std::string& password);
};

} // namespace sf

#endif // SMARTFINANCE_USER_H
