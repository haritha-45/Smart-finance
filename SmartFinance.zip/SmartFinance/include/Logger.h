#ifndef SMARTFINANCE_LOGGER_H
#define SMARTFINANCE_LOGGER_H

#include <string>
#include <fstream>
#include <mutex>

namespace sf {

// Formats a monetary amount to two decimal places, e.g. money(300.0) -> "300.00".
// Declared here (rather than a new header) since Logger.h is already
// included by nearly every module that needs to format an amount for a
// log line or user-facing message.
std::string money(double amount);

enum class LogLevel { DEBUG, INFO, WARN, ERR };

// Logger
// Writes structured, single-line log entries to logs/application.log using:
//   Timestamp | Level | Module | Event | Description
// Implemented as a thread-safe singleton so every module can log through
// one shared sink without passing a Logger instance around.
class Logger {
public:
    static Logger& instance();

    void setLogFile(const std::string& path);
    void log(LogLevel level, const std::string& module,
              const std::string& event, const std::string& description);

    // Convenience wrappers
    void info(const std::string& module, const std::string& event, const std::string& description);
    void warn(const std::string& module, const std::string& event, const std::string& description);
    void error(const std::string& module, const std::string& event, const std::string& description);
    void debug(const std::string& module, const std::string& event, const std::string& description);

private:
    Logger();
    ~Logger();
    Logger(const Logger&) = delete;
    Logger& operator=(const Logger&) = delete;

    static std::string levelToString(LogLevel level);
    static std::string currentTimestamp();

    std::ofstream out_;
    std::mutex mutex_;
};

} // namespace sf

#endif // SMARTFINANCE_LOGGER_H
