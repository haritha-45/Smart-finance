#ifndef SMARTFINANCE_RECOMMENDATIONENGINE_H
#define SMARTFINANCE_RECOMMENDATIONENGINE_H

#include <string>
#include <map>
#include <vector>
#include "Budget.h"

namespace sf {

// A single generated suggestion, with a rationale the user can review
// before approving or modifying it (see FR-018 / BR-018).
struct Recommendation {
    std::string type;            // e.g. "ALLOCATION", "SAVING_REDUCTION"
    std::string suggestedAction;
    double amount = 0.0;
};

// RecommendationEngine
// Generates category spending recommendations, additional-income
// allocation suggestions, and savings/investment guidance.
class RecommendationEngine {
public:
    // Suggests how to split additional (mid-month) income across savings,
    // emergency fund, investment, goals, and flexible spending.
    static std::map<std::string, double> recommendAllocation(double additionalIncome);

    // Analyzes a budget and proposes category-level reductions where
    // spending is running high relative to its limit.
    static std::vector<Recommendation> recommendSavingReductions(const Budget& budget);

    // Suggests category weights for a fresh monthly plan based on prior
    // month's spend distribution (falls back to sensible defaults when no
    // history is available).
    static std::map<std::string, double> recommendCategoryWeights(const Budget* previousMonthBudget);
};

} // namespace sf

#endif // SMARTFINANCE_RECOMMENDATIONENGINE_H
