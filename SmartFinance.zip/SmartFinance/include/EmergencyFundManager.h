#ifndef SMARTFINANCE_EMERGENCYFUNDMANAGER_H
#define SMARTFINANCE_EMERGENCYFUNDMANAGER_H

#include <string>

namespace sf {

// EmergencyFundManager
// Maintains the previous-month surplus reserve, completely separate from
// the current month's normal spending budget, and evaluates eligibility
// for emergency use. Reserve funds are only ever withdrawn after explicit
// user approval (FR-054) -- this class never authorizes a withdrawal on
// its own.
class EmergencyFundManager {
public:
    explicit EmergencyFundManager(double initialReserve = 0.0);

    double reserveAmount() const { return reserveAmount_; }

    // Called at month-end: adds a (non-negative) surplus to the reserve
    // instead of letting it flow into next month's normal budget.
    void addSurplus(double surplus);

    // True if the shortfall could reasonably be covered by the reserve.
    bool isEligibleForUse(double shortfallAmount) const;

    // Withdraws from the reserve. Callers must have already obtained user
    // approval (see RecommendationEngine + main.cpp emergency-expense flow).
    bool withdraw(double amount);

    void save() const;

private:
    double reserveAmount_;
};

} // namespace sf

#endif // SMARTFINANCE_EMERGENCYFUNDMANAGER_H
