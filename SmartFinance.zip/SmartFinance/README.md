# SmartFinance

Smart Personal Finance Management and Financial Intelligence System (C++17)
Reference implementation of the 14 modules described in the project's
Software Requirements and Design Document.

## Build

```bash
make          # builds bin/smartfinance
make run      # builds, then runs the demo
make clean    # removes build/ and bin/
```

Requires g++ with C++17 support and GNU Make. No external libraries are
required to build.

## What the demo does

Running `bin/smartfinance` walks through one full monthly cycle, mirroring
the sequence diagrams in the design document:

1. User login
2. Beginning-of-month planning (salary, fixed expenses, generated budget)
3. Expense entry with live budget tracking and alerts
4. Additional (mid-month) income with an allocation recommendation
5. An emergency-expense scenario checked against the emergency reserve
6. An informational investment suggestion
7. Month-end processing, where the remaining balance is moved into the
   emergency reserve -- never into next month's normal spending budget

## Module map

| Module | Files | Responsibility |
|---|---|---|
| User | User.h/.cpp | Profile + login (absorbs Authentication Manager) |
| Transaction | Transaction.h/.cpp | Base class for a recorded financial event |
| Income | Income.h/.cpp | Salary / additional income (extends Transaction) |
| Expense | Expense.h/.cpp | Categorized spend (extends Transaction) |
| Budget | Budget.h/.cpp | Category limits, spend tracking, remaining/exceeded checks |
| MonthlyPlan | MonthlyPlan.h/.cpp | Beginning-of-month plan generation |
| Report | Report.h/.cpp | Daily / weekly / beginning-of-month / month-end reports |
| RecommendationEngine | RecommendationEngine.h/.cpp | Allocation & saving-reduction suggestions |
| AlertManager | AlertManager.h/.cpp | Budget alerts (absorbs Notification Manager) |
| SavingsManager | SavingsManager.h/.cpp | Savings goal progress |
| InvestmentAnalyzer | InvestmentAnalyzer.h/.cpp | Educational investment suggestions |
| EmergencyFundManager | EmergencyFundManager.h/.cpp | Previous-month surplus reserve |
| DatabaseManager | DatabaseManager.h/.cpp | Persistence abstraction (flat file) |
| Logger | Logger.h/.cpp | Structured application logging |

## Persistence note

`DatabaseManager` persists to `database/smartfinance.db` as a simple
delimited flat file, not real SQLite -- the build environment used to
produce this code did not have the `libsqlite3` development headers
available. The public interface (`insertRow` / `queryTable` / `deleteTable`,
keyed by table name) is storage-agnostic by design: swap the method bodies
for `sqlite3_prepare_v2` / `sqlite3_step` calls, link with `-lsqlite3`, and
no other module needs to change.

## Directories

- `include/` - public headers
- `src/` - implementation files + `main.cpp`
- `database/` - flat-file data store (created by `make dirs`)
- `logs/` - `application.log`
- `reports/`, `tests/`, `docs/` - reserved for generated reports, tests, and docs
